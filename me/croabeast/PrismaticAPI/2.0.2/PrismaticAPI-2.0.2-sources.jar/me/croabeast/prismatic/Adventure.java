package me.croabeast.prismatic;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.md_5.bungee.api.ChatColor;
import org.apache.commons.lang.StringUtils;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
final class Adventure implements Formatter<Component>, AdventureBridge {

    private static final Pattern[] PRISMATIC_BLOCK_PATTERNS = new Pattern[] {
            // Multi-color gradient: <#RRGGBB:#RRGGBB:...>text</gradient> or </g>
            Pattern.compile("(?is)<#[a-f\\d]{6}(?::#[a-f\\d]{6})+>.+?</g(?:radient)?>"),
            // g: prefix gradient: <g:RRGGBB>text</g:RRGGBB>
            Pattern.compile("(?is)<g:[a-f\\d]{6}>.+?</g:[a-f\\d]{6}>"),
            // gradient: prefix gradient: <gradient:RRGGBB>text</gradient:RRGGBB>
            Pattern.compile("(?is)<gradient:[a-f\\d]{6}>.+?</gradient:[a-f\\d]{6}>"),
            // Single hex pair: <#RRGGBB>text</#RRGGBB>
            Pattern.compile("(?is)<#[a-f\\d]{6}>.+?</#[a-f\\d]{6}>"),
            // Rainbow: <rainbow:N>text</rainbow> or <r:N>text</r>
            Pattern.compile("(?is)<rainbow:\\d{1,3}>.+?</rainbow>"),
            Pattern.compile("(?is)<r:\\d{1,3}>.+?</r>")
    };

    private static final Pattern[] SINGLE_COLOR_PATTERNS = new Pattern[] {
            // {#RRGGBB} format
            Pattern.compile("(?i)\\{#([a-f\\d]{6})}"),
            // %#RRGGBB% format
            Pattern.compile("(?i)%#([a-f\\d]{6})%"),
            // [#RRGGBB] format
            Pattern.compile("(?i)\\[#([a-f\\d]{6})]"),
            // &xRRGGBB format
            Pattern.compile("(?i)&x([a-f\\d]{6})"),
            // #RRGGBB or &#RRGGBB - NOT preceded by <, /, or : to avoid corrupting
            // Prismatic gradient syntax (:#RRGGBB) or MiniMessage tags (<#RRGGBB>)
            Pattern.compile("(?i)(?<![</:])&?#([a-f\\d]{6})")
    };

    private static final Pattern LEGACY_CODE_PATTERN = Pattern.compile("(?i)[&\\u00A7]([0-9a-fk-or])");

    private static final Pattern TAG_PATTERN = Pattern.compile("(?i)</?([a-z\\d_#-]+)(?::[^<>]*)?>");

    /** Gradient and rainbow shorthands owned by Prismatic, which the standard resolver knows nothing about. */
    private static final Set<String> PRISMATIC_TAGS = new HashSet<>(Arrays.asList("g", "r"));

    private static final TagResolver STANDARD_TAGS = TagResolver.standard();

    /**
     * A legacy colour code clears the decorations that are active, which a MiniMessage colour tag
     * does not. Without closing them, a {@code &m} bleeds into every segment that follows it.
     * {@code <reset>} would close them too, but it also closes any open click or hover event.
     */
    private static final String CLEAR_DECORATIONS =
            "<!bold><!italic><!underlined><!strikethrough><!obfuscated>";

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_SERIALIZER = LegacyComponentSerializer.legacySection();

    private static final LegacyComponentSerializer HEX_SERIALIZER = LegacyComponentSerializer.builder()
            .character(LegacyComponentSerializer.SECTION_CHAR)
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    private final PrismaticCore core;

    @Override
    public ChatColor fromString(String string, boolean legacy) {
        return core.fromString(string, legacy);
    }

    @Override
    public Component applyColor(Color color, String string, boolean legacy) {
        return deserialize(core.applyColor(color, string, legacy), legacy);
    }

    @Override
    public Component applyGradient(String string, Color start, Color end, boolean legacy) {
        return deserialize(core.applyGradient(string, start, end, legacy), legacy);
    }

    @Override
    public Component applyRainbow(String string, float saturation, boolean legacy) {
        return deserialize(core.applyRainbow(string, saturation, legacy), legacy);
    }

    @Override
    public Component colorize(@Nullable Player player, String string) {
        return StringUtils.isBlank(string) ?
                Component.text(string == null ? "" : string) :
                colorizeComponent(string, core.shouldUseLegacyColors(player));
    }

    @Override
    public String stripBukkit(String string) {
        return core.stripBukkit(string);
    }

    @Override
    public String stripSpecial(String string) {
        return core.stripSpecial(string);
    }

    @Override
    public String stripRGB(String string) {
        return core.stripRGB(string);
    }

    @Override
    public String stripMiniMessage(String string) {
        return StringUtils.isBlank(string) ? string : MINI_MESSAGE.stripTags(string);
    }

    @Override
    public String stripAll(String string) {
        return core.stripAll(string);
    }

    @Override
    public boolean startsWithColor(String string) {
        return core.startsWithColor(string);
    }

    @Override
    public String getStartColor(String string) {
        return core.getStartColor(string);
    }

    @Override
    public String getEndColor(String string) {
        return core.getEndColor(string);
    }

    @Override
    public String colorizeLegacy(String string, boolean legacy) {
        return StringUtils.isBlank(string) ? string == null ? "" : string :
                !hasMarkup(string) ?
                        core.applyLegacyPipeline(string, legacy) :
                        serialize(colorizeComponent(string, legacy), legacy);
    }

    @Override
    public boolean hasMarkup(String string) {
        if (StringUtils.isBlank(string) || string.indexOf('<') == -1) return false;

        Matcher matcher = TAG_PATTERN.matcher(string);
        while (matcher.find()) {
            String name = matcher.group(1).toLowerCase(Locale.ENGLISH);
            if (PRISMATIC_TAGS.contains(name) || STANDARD_TAGS.has(name)) return true;
        }

        return false;
    }

    private TokenizedComponents maskPrismaticBlocks(String string, boolean legacy) {
        List<Token<Component>> tokens = new ArrayList<>();
        for (Pattern pattern : PRISMATIC_BLOCK_PATTERNS) {
            string = maskComponentMatches(string, pattern, legacy, tokens);
        }
        return new TokenizedComponents(string, tokens);
    }

    private String normalizeMiniMessage(String string) {
        for (Pattern pattern : SINGLE_COLOR_PATTERNS) {
            string = replaceMatches(string, pattern, matcher -> CLEAR_DECORATIONS + "<#" + matcher.group(1) + ">");
        }

        return replaceMatches(string, LEGACY_CODE_PATTERN, matcher -> legacyTag(matcher.group(1).charAt(0)));
    }

    private String legacyTag(char code) {
        char lower = Character.toLowerCase(code);
        boolean colour = (lower >= '0' && lower <= '9') || (lower >= 'a' && lower <= 'f');
        return colour ? CLEAR_DECORATIONS + namedTag(code) : namedTag(code);
    }

    private String namedTag(char code) {
        switch (Character.toLowerCase(code)) {
            case '0':
                return "<black>";
            case '1':
                return "<dark_blue>";
            case '2':
                return "<dark_green>";
            case '3':
                return "<dark_aqua>";
            case '4':
                return "<dark_red>";
            case '5':
                return "<dark_purple>";
            case '6':
                return "<gold>";
            case '7':
                return "<gray>";
            case '8':
                return "<dark_gray>";
            case '9':
                return "<blue>";
            case 'a':
                return "<green>";
            case 'b':
                return "<aqua>";
            case 'c':
                return "<red>";
            case 'd':
                return "<light_purple>";
            case 'e':
                return "<yellow>";
            case 'f':
                return "<white>";
            case 'k':
                return "<obfuscated>";
            case 'l':
                return "<bold>";
            case 'm':
                return "<strikethrough>";
            case 'n':
                return "<underlined>";
            case 'o':
                return "<italic>";
            case 'r':
                return "<reset>";
            default:
                return String.valueOf(code);
        }
    }

    private String maskComponentMatches(
            String string,
            Pattern pattern,
            boolean legacy,
            List<Token<Component>> tokens
    ) {
        Matcher matcher = pattern.matcher(string);
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String token = token(tokens.size());
            String legacyValue = core.applyLegacyPipeline(matcher.group(), legacy);
            tokens.add(new Token<>(token, deserialize(legacyValue, legacy)));
            matcher.appendReplacement(result, Matcher.quoteReplacement(token));
        }
        matcher.appendTail(result);
        return result.toString();
    }

    private Component replaceComponentTokens(Component component, List<Token<Component>> tokens) {
        for (Token<Component> token : tokens) {
            component = component.replaceText(builder -> builder.matchLiteral(token.key).replacement(token.value));
        }
        return component;
    }

    private String replaceMatches(String string, Pattern pattern, Replacer replacer) {
        Matcher matcher = pattern.matcher(string);
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(result, Matcher.quoteReplacement(replacer.replace(matcher)));
        }
        matcher.appendTail(result);
        return result.toString();
    }

    private Component downsample(Component component) {
        TextColor color = component.color();
        component = color != null && !(color instanceof NamedTextColor) ?
                component.color(NamedTextColor.nearestTo(color)) :
                component;

        List<Component> children = component.children();
        return children.isEmpty() ? component : component.children(mapChildren(children));
    }

    private List<Component> mapChildren(List<Component> children) {
        List<Component> mapped = new ArrayList<>(children.size());
        for (Component child : children) {
            mapped.add(downsample(child));
        }

        return mapped;
    }

    private String token(int index) {
        return "__PRISM_MM_TOKEN_" + index + "__";
    }

    private Component colorizeComponent(String string, boolean legacy) {
        return !hasMarkup(string) ?
                deserialize(core.applyLegacyPipeline(string, legacy), legacy) :
                colorizeMiniMessageComponent(string, legacy);
    }

    private Component colorizeMiniMessageComponent(String string, boolean legacy) {
        // 1. Mask Prismatic blocks (gradient, rainbow, hex pairs) before any normalization
        //    so their content is never touched by subsequent steps.
        TokenizedComponents masked = maskPrismaticBlocks(string, legacy);

        // 2. Convert remaining legacy (&a, &c ...) and bare hex (#RRGGBB) to MiniMessage tags.
        //    The fixed lookbehind in SINGLE_COLOR_PATTERNS prevents corrupting :#RRGGBB inside
        //    any gradient tag that escaped masking.
        String normalized = normalizeMiniMessage(masked.value);

        // 3. MiniMessage parses its own tags: <green>, <#RRGGBB>, <gradient:#...>, <bold>, etc.
        //    Default resolvers are active; TagResolver.empty() only means no extra custom tags.
        Component component = MINI_MESSAGE.deserialize(normalized, TagResolver.empty());

        // 4. Restore Prismatic-processed tokens (gradient, rainbow, hex pairs).
        component = replaceComponentTokens(component, masked.tokens);

        // 5. Downsample to 16-color palette only for legacy targets (< 1.16 players).
        return legacy ? downsample(component) : component;
    }

    private Component deserialize(String value, boolean legacy) {
        return serializer(legacy).deserialize(value == null ? "" : value);
    }

    private String serialize(Component component, boolean legacy) {
        return serializer(legacy).serialize(component);
    }

    /**
     * The legacy target only ever holds the sixteen colors, so the plain serializer is right for it.
     * The hex target must round-trip the {@code §x§r§r§g§g§b§b} form the color engine emits, which
     * the plain serializer neither parses nor writes: using it there downsampled every hex color to
     * its nearest named one, for every message containing a {@code '<'}.
     */
    private LegacyComponentSerializer serializer(boolean legacy) {
        return legacy ? LEGACY_SERIALIZER : HEX_SERIALIZER;
    }

    @FunctionalInterface
    private interface Replacer {
        String replace(Matcher matcher);
    }

    private static final class Token<T> {

        private final String key;
        private final T value;

        private Token(String key, T value) {
            this.key = key;
            this.value = value;
        }
    }

    private static final class TokenizedComponents {

        private final String value;
        private final List<Token<Component>> tokens;

        private TokenizedComponents(String value, List<Token<Component>> tokens) {
            this.value = value;
            this.tokens = Collections.unmodifiableList(tokens);
        }
    }
}
