package me.croabeast.inventory.pane;

import lombok.Getter;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.PositionedPane;
import me.croabeast.inventory.pane.util.Slot;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;
import java.util.stream.Collectors;

/**
 * A pane for panes that should be spread out over multiple pages
 */
public class PaginatedPane extends Pane {

    /**
     * A set of panes for the different pages
     */
    @NotNull
    private final List<List<PositionedPane>> panes = new ArrayList<>();

    /**
     * The current page
     */
    @Getter
    private int page;

    /**
     * Creates a new paginated pane
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @param priority the priority of the pane
     * @since 0.1.0
     */
    public PaginatedPane(int length, int height, @NotNull Priority priority) {
        super(length, height, priority);
    }

    /**
     * Creates a new paginated pane
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @since 0.1.0
     */
    public PaginatedPane(int length, int height) {
        this(length, height, Priority.NORMAL);
    }

    /**
     * Returns the amount of pages
     *
     * @return the amount of pages
     */
    public int getPages() {
        return panes.size();
    }

    /**
     * Adds the specified pane to a new page. The new page will be at the index one after the highest indexed page
     * currently in this paginated pane. If this paginated pane has no pages, the index of the newly created page will
     * be zero.
     *
     * @param slot the slot of the pane
     * @param pane the pane to add to a new page
     * @since 0.1.0
     */
    public void addPage(@NotNull Slot slot, @NotNull Pane pane) {
        List<PositionedPane> list = new ArrayList<>(1);

        list.add(new PositionedPane(slot, pane));

        this.panes.add(list);
    }

    /**
     * Adds a pane to a selected page. If the page does not exist and is exactly one larger than the current highest
     * page index, this method will create a new page with the specified pane. If the page does not exist and is more
     * than one larger than the current highest page index, this method will throw an {@link IllegalArgumentException}.
     * If the page is negative, an {@link IllegalArgumentException} will also be thrown. If there are currently no
     * pages, only index 0 is valid and will create a new page with the specified pane added to it.
     * <p>
     * For example, if the pages 0, 1, ..., n currently exist, then:
     * <ul>
     *     <li>Indexes &lt; 0 will throw an exception</li>
     *     <li>Indexes 0, 1, ..., n will add the pane to the respective page</li>
     *     <li>Index n + 1 will create a new page with the specified pane</li>
     *     <li>Indexes &gt; n + 1 will throw an exception</li>
     * </ul>
     *
     * @param page the page to assign the pane to
     * @param slot the slot of the pane
     * @param pane the new pane
     * @throws IllegalArgumentException if the page is less than 0 or more than one larger than the current highest page
     * index
     */
    public void addPane(int page, @NotNull Slot slot, @NotNull Pane pane) {
        if (page < 0)
            throw new IllegalArgumentException("Non-positive page indexes are not allowed");

        if (page > this.panes.size())
            throw new IllegalArgumentException("Page index outside range of existing pages");

        if (page == this.panes.size()) {
            addPage(slot, pane);
        } else {
            this.panes.get(page).add(new PositionedPane(slot, pane));

            this.panes.get(page).sort(Comparator.comparing(positionedPane -> positionedPane.getPane().getPriority()));
        }
    }

    /**
     * Sets the current displayed page. If the specified page does not exist an {@link ArrayIndexOutOfBoundsException}
     * is thrown.
     *
     * @param page the page
     * @throws ArrayIndexOutOfBoundsException if the page does not exist
     */
    public void setPage(int page) {
        if (page < 0 || page >= this.panes.size())
            throw new ArrayIndexOutOfBoundsException("Page outside of range");

		this.page = page;
    }

	/**
	 * Populates the PaginatedPane based on the provided list by adding new pages until all items can fit.
	 * This can be helpful when dealing with lists of unknown size.
	 *
	 * @param items The list to populate the pane with
     * @param plugin the plugin that will be the owner of the items created
     * @see #populateWithItemStacks(List)
     * @since 0.1.0
	 */
	public void populateWithItemStacks(@NotNull List<@NotNull ItemStack> items, @NotNull Plugin plugin) {
		//Don't do anything if the list is empty
		if (items.isEmpty()) {
		    return;
        }

		int itemsPerPage = this.height * this.length;
		int pagesNeeded = (int) Math.max(Math.ceil(items.size() / (double) itemsPerPage), 1);

		for (int i = 0; i < pagesNeeded; i++) {
			OutlinePane page = new OutlinePane(this.length, this.height);

			for (int j = 0; j < itemsPerPage; j++) {
				//Check if the loop reached the end of the list
				int index = i * itemsPerPage + j;

				if (index >= items.size()) {
				    break;
                }

				page.addItem(new GuiItem(items.get(index), plugin));
			}

			this.addPane(i, Slot.fromIndex(0), page);
		}
	}

    /**
     * Populates the PaginatedPane based on the provided list by adding new pages until all items can fit.
     * This can be helpful when dealing with lists of unknown size.
     *
     * @param items The list to populate the pane with
     */
    public void populateWithItemStacks(@NotNull List<ItemStack> items) {
        populateWithItemStacks(items, JavaPlugin.getProvidingPlugin(PaginatedPane.class));
    }

    /**
     * Populates the PaginatedPane based on the provided list by adding new pages until all items can fit.
     * This can be helpful when dealing with lists of unknown size.
     *
     * @param items The list to populate the pane with
     */
    public void populateWithGuiItems(@NotNull List<GuiItem> items) {
        //Don't do anything if the list is empty
        if (items.isEmpty())
            return;

        int itemsPerPage = this.height * this.length;
        int pagesNeeded = (int) Math.max(Math.ceil(items.size() / (double) itemsPerPage), 1);

        for (int i = 0; i < pagesNeeded; i++) {
            OutlinePane page = new OutlinePane(this.length, this.height);

            for (int j = 0; j < itemsPerPage; j++) {
                int index = i * itemsPerPage + j;

				//Check if the loop reached the end of the list
                if (index >= items.size())
                    break;

                page.addItem(items.get(index));
            }

            this.addPane(i, Slot.fromIndex(0), page);
        }
    }

	/**
	 * This method creates a list of ItemStacks all with the given {@code material} and the display names.
	 * After that it calls {@link #populateWithItemStacks(List)}
	 * This method also translates the color char {@code &} for all names.
	 *
	 * @param displayNames The display names for all the items
	 * @param material The material to use for the {@link org.bukkit.inventory.ItemStack}s
     * @param plugin the plugin that will be the owner of the created items
     * @see #populateWithNames(List, Material)
     * @since 0.1.0
	 */
	public void populateWithNames(@NotNull List<String> displayNames, @Nullable Material material,
                                  @NotNull Plugin plugin) {
		if(material == null || material == Material.AIR) return;

		populateWithItemStacks(displayNames.stream().map(name -> {
			ItemStack itemStack = new ItemStack(material);
			ItemMeta itemMeta = itemStack.getItemMeta();
			itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
			itemStack.setItemMeta(itemMeta);
			return itemStack;
		}).collect(Collectors.toList()), plugin);
	}

    /**
     * This method creates a list of ItemStacks all with the given {@code material} and the display names.
     * After that it calls {@link #populateWithItemStacks(List)}
     * This method also translates the color char {@code &} for all names.
     *
     * @param displayNames The display names for all the items
     * @param material The material to use for the {@link org.bukkit.inventory.ItemStack}s
     */
    public void populateWithNames(@NotNull List<String> displayNames, @Nullable Material material) {
        populateWithNames(displayNames, material, JavaPlugin.getProvidingPlugin(PaginatedPane.class));
    }

    @NotNull
    public GuiItemContainer display() {
        GuiItemContainer container = new GuiItemContainer(getLength(), getHeight());

        if (this.page < 0 || this.page >= this.panes.size())
            return container;

        List<PositionedPane> panes = this.panes.get(page);

        if (panes == null)
            return container;

        for (PositionedPane positionedPane : panes) {
            Pane pane = positionedPane.getPane();

            if (!pane.isVisible())
                continue;

            Slot slot = positionedPane.getSlot();

            container.apply(pane.display(), slot.getX(getLength()), slot.getY(getLength()));
        }

        return container;
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        //this isn't our item
        if (x < 0 || x >= getLength() || y < 0 || y >= getHeight())
            return false;

		callOnClick(event);

        boolean success = false;

        if (this.page < 0 || this.page >= this.panes.size())
            return false;

        for (PositionedPane positionedPane : this.panes.get(this.page)) {
            Pane pane = positionedPane.getPane();

            if (!pane.isVisible())
                continue;

            Slot paneSlot = positionedPane.getSlot();
            Slot innerSlot = Slot.fromXY(x - paneSlot.getX(getLength()), y - paneSlot.getY(getLength()));

            success = success || pane.click(gui, guiComponent, event, innerSlot);
        }

        return success;
    }

    @NotNull
    public PaginatedPane copy() {
	    PaginatedPane paginatedPane = new PaginatedPane(this.length, this.height, getPriority());

        for (int page = 0; page < this.panes.size(); page++) {
            List<? extends PositionedPane> panes = this.panes.get(page);

            for (PositionedPane positionedPane : panes) {
                paginatedPane.addPane(page, positionedPane.getSlot(), positionedPane.getPane().copy());
            }
        }

        paginatedPane.setVisible(isVisible());
        paginatedPane.onClick = this.onClick;

        paginatedPane.uuid = this.uuid;

        paginatedPane.page = this.page;

        return paginatedPane;
    }

    /**
     * Deletes a page and all its associated panes from this paginated pane. It also decrements the indexes of all pages
     * beyond the specified page by one. For example, given a sequence of pages 0, 1, 2, 3, 4, upon removing page 2, the
     * new sequence of pages will be 0, 1, 2, 3. If the specified page does not exist, then this method will silently do
     * nothing.
     *
     * @param page the page to delete
     * @since 0.1.0
     */
    public void deletePage(int page) {
        if (page < 0 || page >= this.panes.size())
            return;

        this.panes.remove(page);
    }

    @NotNull
    public Collection<Pane> getPanes() {
        Collection<Pane> panes = new HashSet<>();

        for (List<? extends PositionedPane> positionedPanes : this.panes) {
            for (PositionedPane positionedPane : positionedPanes) {
                panes.add(positionedPane.getPane());
            }
        }

        return panes;
    }

    /**
     * Gets all the panes from inside the specified page of this pane. If the specified page is not existent, this
     * method will throw an {@link IllegalArgumentException}. If the specified page is existent, but doesn't
     * have any panes, the returned collection will be empty. The returned collection is unmodifiable. The returned
     * collection is not synchronized and no guarantees should be made as to the safety of concurrently accessing the
     * returned collection. If synchronized behaviour should be allowed, the returned collection must be synchronized
     * externally.
     *
     * @param page the panes of this page will be returned
     * @return a collection of panes belonging to the specified page
     * @since 0.1.0
     * @throws IllegalArgumentException if the page does not exist
     */
    @NotNull
    public Collection<Pane> getPanes(int page) {
        if (page < 0 || this.page >= this.panes.size())
            throw new IllegalArgumentException("Invalid page");

        Collection<? extends PositionedPane> positionedPanes = this.panes.get(page);

        if (positionedPanes == null)
            throw new IllegalArgumentException("Invalid page");

        Collection<Pane> panes = new HashSet<>(positionedPanes.size());

        for (PositionedPane positionedPane : positionedPanes) {
            panes.add(positionedPane.getPane());
        }

        return Collections.unmodifiableCollection(panes);
    }

    @NotNull
    public Collection<GuiItem> getItems() {
        return getPanes().stream().flatMap(pane -> pane.getItems().stream()).collect(Collectors.toList());
    }

    @Override
    public void clear() {
        panes.clear();
    }

    /**
     * Loads a paginated pane from a given element
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will be used to create the items
     * @return the paginated pane
     * @since 0.1.0
     */
    @NotNull
    public static PaginatedPane load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Paginated pane XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Paginated pane XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        PaginatedPane paginatedPane = new PaginatedPane(length, height);

        Pane.load(paginatedPane, instance, element);

        if (element.hasAttribute("id")) {
            element.setIdAttribute("id", true);
            element.setUserData("pane", paginatedPane, null);
        }

        if (element.hasAttribute("populate"))
            return paginatedPane;

        int pageCount = 0;

        NodeList childNodes = element.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node item = childNodes.item(i);
            if (item.getNodeType() != Node.ELEMENT_NODE)
                continue;

            if(!item.getNodeName().equals("page"))
                throw new XMLLoadException("Panes have to be inside page tag");

            NodeList innerNodes = item.getChildNodes();

            for (int j = 0; j < innerNodes.getLength(); j++) {
                Node innerNode = innerNodes.item(j);

                if (innerNode.getNodeType() != Node.ELEMENT_NODE)
                    continue;

                Pane pane = Gui.loadPane(instance, innerNode, plugin);

                paginatedPane.addPane(pageCount, Slot.deserialize((Element) innerNode), pane);
            }

            pageCount++;
        }

        return paginatedPane;
    }
}
