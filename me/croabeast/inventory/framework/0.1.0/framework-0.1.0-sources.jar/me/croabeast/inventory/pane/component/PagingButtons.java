package me.croabeast.inventory.pane.component;

import lombok.Setter;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.pane.PaginatedPane;
import me.croabeast.inventory.pane.Pane;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Slot;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

/**
 * An interface for interacting with {@link PaginatedPane}s. This gives two buttons for navigating backwards and
 * forwards through the pages of the {@link PaginatedPane}. The backward button will be displayed at (0, 0) of this pane
 * and the forward button will be displayed at (length - 1, 0) of this pane. If the paginated pane is at the first page
 * or the last page, the backwards respectively the forward button will not show. This does not display the
 * {@link PaginatedPane} itself, but is merely an interface for interacting with it.
 * 
 * @since 0.1.0
 */
public class PagingButtons extends Pane {

    /**
     * The paginated pane.
     */
    @NotNull
    private final PaginatedPane pages;

    /**
     * The backwards button.
     */
    @NotNull
    @Setter
    private GuiItem backwardButton;

    /**
     * The forwards button.
     */
    @NotNull
    @Setter
    private GuiItem forwardButton;

    /**
     * Whether to keep the backward/forward button always visible
     */
    private boolean keepButtonsVisible;

    /**
     * The plugin with which the items were created.
     */
    @NotNull
    private final Plugin plugin;

    /**
     * Creates a new PagingButtons instance, which controls the provided {@link PaginatedPane}. The backward and forward
     * item will be an arrow. If the length provided is less than 2, this will throw an
     * {@link IllegalArgumentException}.
     *
     * @param length the length of this interface
     * @param priority the priority of this interface
     * @param pages the pages to interact with
     * @param plugin the plugin that will be the owner of this interface's items
     * @since 0.1.0
     * @throws IllegalArgumentException if the length is less than 2
     */
    public PagingButtons(int length, @NotNull Priority priority, @NotNull PaginatedPane pages, @NotNull Plugin plugin) {
        super(length, 1, priority);

        if (length < 2)
            throw new IllegalArgumentException("Length of paging buttons must be at least 2");
        
        this.pages = pages;
        this.plugin = plugin;
        
        this.backwardButton = new GuiItem(new ItemStack(Material.ARROW), plugin);
        this.forwardButton = new GuiItem(new ItemStack(Material.ARROW), plugin);
        this.keepButtonsVisible = false;
    }

    /**
     * Creates a new PagingButtons instance, which controls the provided {@link PaginatedPane}. The backward and forward
     * item will be an arrow. If the length provided is less than 2, this will throw an
     * {@link IllegalArgumentException}.
     *
     * @param length the length of this interface
     * @param priority the priority of this interface
     * @param pages the pages to interact with
     * @since 0.1.0
     * @throws IllegalArgumentException if the length is less than 2
     */
    public PagingButtons(int length, @NotNull Priority priority, @NotNull PaginatedPane pages) {
        this(length, priority, pages, JavaPlugin.getProvidingPlugin(PagingButtons.class));
    }

    /**
     * Creates a new PagingButtons instance, which controls the provided {@link PaginatedPane}. The backward and forward
     * item will be an arrow. If the length provided is less than 2, this will throw an
     * {@link IllegalArgumentException}.
     *
     * @param length the length of this interface
     * @param pages the pages to interact with
     * @param plugin the plugin that will be the owner of this interface's items
     * @since 0.1.0
     * @throws IllegalArgumentException if the length is less than 2
     */
    public PagingButtons(int length, @NotNull PaginatedPane pages, @NotNull Plugin plugin) {
        this(length, Priority.NORMAL, pages, plugin);
    }

    /**
     * Creates a new PagingButtons instance, which controls the provided {@link PaginatedPane}. The backward and forward
     * item will be an arrow. If the length provided is less than 2, this will throw an
     * {@link IllegalArgumentException}.
     *
     * @param length the length of this interface
     * @param pages the pages to interact with
     * @since 0.1.0
     * @throws IllegalArgumentException if the length is less than 2
     */
    public PagingButtons(int length, @NotNull PaginatedPane pages) {
        this(length, Priority.NORMAL, pages);
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        //this isn't our item
        if (x < 0 || x >= getLength() || y < 0 || y >= getHeight())
            return false;

        callOnClick(event);

        ItemStack itemStack = event.getCurrentItem();

        if (itemStack == null)
            return false;

        if (matchesItem(this.backwardButton, itemStack)) {
            try {
                this.pages.setPage(this.pages.getPage() - 1);

                this.backwardButton.callAction(event);

                gui.update();
            } catch (ArrayIndexOutOfBoundsException ignored) {}

            return true;
        }

        if (matchesItem(this.forwardButton, itemStack)) {
            try {
                this.pages.setPage(this.pages.getPage() + 1);

                this.forwardButton.callAction(event);

                gui.update();
            } catch (ArrayIndexOutOfBoundsException ignored) {}

            return true;
        }

        return false;
    }

    @NotNull
    public GuiItemContainer display() {
        GuiItemContainer container = new GuiItemContainer(getLength(), getHeight());

        if (this.keepButtonsVisible || this.pages.getPage() > 0)
            container.setItem(this.backwardButton, 0, 0);

        if (this.keepButtonsVisible || this.pages.getPage() < this.pages.getPages() - 1)
            container.setItem(this.forwardButton, getLength() - 1, 0);

        return container;
    }

    /**
     * {@inheritDoc}
     *
     * This does not make a copy of the {@link PaginatedPane} that is being controlled by this interface.
     */
    @NotNull
    public PagingButtons copy() {
        PagingButtons pagingButtons = new PagingButtons(getLength(), getPriority(), this.pages, this.plugin);

        pagingButtons.setVisible(isVisible());
        pagingButtons.onClick = super.onClick;

        pagingButtons.uuid = super.uuid;

        pagingButtons.backwardButton = this.backwardButton.copy();
        pagingButtons.forwardButton = this.forwardButton.copy();

        return pagingButtons;
    }

    @NotNull
    public Collection<GuiItem> getItems() {
        Collection<GuiItem> items = new HashSet<>();

        items.add(this.backwardButton);
        items.add(this.forwardButton);

        return Collections.unmodifiableCollection(items);
    }

    /**
     * Allow to always keep the backward and forward buttons visible when on the first and last page
     *
     * @param visible Whether to keep the buttons visible
     * @since 0.1.0
     */
    public void setButtonsAlwaysVisible(boolean visible) {
        this.keepButtonsVisible = visible;
    }

    @NotNull
    public Collection<Pane> getPanes() {
        return Collections.emptySet();
    }

    /**
     * This is a no-op.
     *
     * @since 0.1.0
     */
    @Override
    public void clear() {}

    /**
     * Loads a paging buttons pane from an XML element.
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will be the owner of the underlying items
     * @return the paging buttons pane
     * @since 0.1.0
     */
    @NotNull
    public static PagingButtons load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Paging buttons XML tag does not have the mandatory length attribute");

        int length;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        if (!element.hasAttribute("pages"))
            throw new XMLLoadException("Paging buttons does not have pages attribute");

        Element paginatedPaneElement = element.getOwnerDocument().getElementById(element.getAttribute("pages"));

        if (paginatedPaneElement == null)
            throw new XMLLoadException("Paging buttons pages reference is invalid");

        Object paginatedPane = paginatedPaneElement.getUserData("pane");

        if (!(paginatedPane instanceof PaginatedPane))
            throw new XMLLoadException("Retrieved data is not a paginated pane");

        PagingButtons pagingButtons = new PagingButtons(length, (PaginatedPane) paginatedPane);

        Pane.load(pagingButtons, instance, element);

        return pagingButtons;
    }
}
