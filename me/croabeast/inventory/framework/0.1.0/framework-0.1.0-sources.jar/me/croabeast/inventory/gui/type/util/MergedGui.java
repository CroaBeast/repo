package me.croabeast.inventory.gui.type.util;

import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.pane.Pane;
import me.croabeast.inventory.pane.util.Slot;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.List;

/**
 * Represents a chest-like gui in which the top and bottom inventories are merged together and only exist of one
 * inventory component.
 *
 * @since 0.1.0
 */
public interface MergedGui {

    /**
     * Adds a pane to this gui
     *
     * @param slot the position of the pane
     * @param pane the pane to add
     * @since 0.1.0
     */
    void addPane(@NotNull Slot slot, @NotNull Pane pane);

    /**
     * Gets all the panes in this gui. This includes child panes from other panes.
     *
     * @return all panes
     * @since 0.1.0
     */
    @NotNull
    List<Pane> getPanes();

    /**
     * Gets all the items in all underlying panes
     *
     * @return all items
     * @since 0.1.0
     */
    @NotNull
    Collection<GuiItem> getItems();

    /**
     * Gets the gui component for this gui
     *
     * @return the gui component
     * @since 0.1.0
     */
    @NotNull
    GuiComponent getGuiComponent();
}
