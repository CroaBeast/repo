package me.croabeast.inventory.pane;

import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Slot;
import me.croabeast.inventory.util.GeometryUtil;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;
import java.util.function.Consumer;

/**
 * A pane for static items and stuff. All items will have to be specified a slot, or will be added in the next position.
 * <p>
 * This pane allows you to specify the positions of the items either in the form of an x and y coordinate pair or as an
 * index, in which case the indexing starts from the top left and continues to the right and bottom, with the horizontal
 * axis taking priority. There are nuances at play with regard to mixing these two types of positioning systems within
 * the same pane. It's recommended to only use one of these systems per pane and to not mix them.
 * </p>
 */
public class StaticPane extends Pane implements Flippable, Rotatable {

	/**
	 * A map of locations inside this pane and their item.
	 */
	@NotNull
	private final Map<Slot, GuiItem> items;

	/**
	 * The clockwise rotation of this pane in degrees
	 */
	private int rotation;

	/**
	 * Whether the items should be flipped horizontally and/or vertically
	 */
	private boolean flipHorizontally, flipVertically;

    /**
     * Creates a new static pane.
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @param priority the priority of the pane
     * @since 0.1.0
     */
    public StaticPane(int length, int height, @NotNull Priority priority) {
        super(length, height, priority);

        this.items = new HashMap<>(length * height);
    }

    /**
     * Creates a new static pane.
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @since 0.1.0
     */
    public StaticPane(int length, int height) {
        this(length, height, Priority.NORMAL);
    }

    @NotNull
	public GuiItemContainer display() {
        GuiItemContainer container = new GuiItemContainer(getLength(), getHeight());

		items.entrySet().stream().filter(entry -> entry.getValue().isVisible()).forEach(entry -> {
			Slot location = entry.getKey();

			int x = location.getX(getLength());
            int y = location.getY(getLength());

			if (flipHorizontally)
				x = length - x - 1;

			if (flipVertically)
				y = height - y - 1;

			Map.Entry<Integer, Integer> coordinates = GeometryUtil.processClockwiseRotation(x, y, getLength(),
                    getHeight(), rotation);

			x = coordinates.getKey();
			y = coordinates.getValue();

			if (x < 0 || x >= getLength() || y < 0 || y >= getHeight()) {
			    return;
            }

            container.setItem(entry.getValue(), x, y);
		});

        return container;
	}

    /**
     * Adds a gui item at the specific spot in the pane. If the specified slot is already in use, the previous item will
     * be overwritten by the new item. This is regardless of the way the slot is specified.
     *
     * @param item the item to set
     * @param slot the position of the item
     * @since 0.1.0
     */
    public void addItem(@NotNull GuiItem item, Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        this.items.keySet().removeIf(s -> s.getX(getLength()) == x && s.getY(getLength()) == y);

        this.items.put(slot, item);
    }

	/**
	 * Adds a gui item at the specific spot in the pane. If there is another item specified in terms of x and y
     * coordinates that are equal to the coordinates of this item, the old item will be overwritten by this item.
	 *
	 * @param item the item to set
	 * @param x    the x coordinate of the position of the item
     * @param y    the y coordinate of the position of the item
	 */
	public void addItem(@NotNull GuiItem item, int x, int y) {
		addItem(item, Slot.fromXY(x, y));
	}

    /**
     * Removes the specified item from the pane
     *
     * @param item the item to remove
     * @since 0.1.0
     */
    public void removeItem(@NotNull GuiItem item) {
        items.values().removeIf(guiItem -> guiItem.equals(item));
    }

    /**
     * Removes the specified item from the pane. This will remove an item regardless of how the slot was specified. If
     * there is no item at the specified coordinates, this method will do nothing.
     *
     * @param x the x coordinate of the item to remove
     * @param y the y coordinate of the item to remove
     * @since 0.1.0
     * @see #removeItem(Slot)
     */
    public void removeItem(int x, int y) {
        this.items.keySet().removeIf(s -> s.getX(getLength()) == x && s.getY(getLength()) == y);
    }

    /**
     * Removes the specified item from the pane. This will remove an item regardless of how the slot was specified. If
     * there is no item at the specified coordinates, this method will do nothing.
     *
     * @param slot the slot of the item to remove
     * @since 0.1.0
     */
    public void removeItem(@NotNull Slot slot) {
        removeItem(slot.getX(getLength()), slot.getY(getLength()));
    }

	@Override
	public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

		//this isn't our item
		if (x < 0 || x >= getLength() || y < 0 || y >= getHeight()) {
            return false;
        }

		callOnClick(event);

        ItemStack itemStack = event.getCurrentItem();

        if (itemStack == null)
            return false;

        GuiItem clickedItem = findMatchingItem(items.values(), itemStack);

        if (clickedItem == null)
            return false;

        clickedItem.callAction(event);

        return true;
	}

    @NotNull
    public StaticPane copy() {
        StaticPane staticPane = new StaticPane(getLength(), getHeight(), getPriority());

        for (Map.Entry<Slot, GuiItem> entry : items.entrySet()) {
            staticPane.addItem(entry.getValue().copy(), entry.getKey());
        }

        staticPane.setVisible(isVisible());
        staticPane.onClick = onClick;

        staticPane.uuid = uuid;

        staticPane.rotation = rotation;
        staticPane.flipHorizontally = flipHorizontally;
        staticPane.flipVertically = flipVertically;

        return staticPane;
    }

    @Override
	public void setRotation(int rotation) {
		if (length != height) {
			throw new UnsupportedOperationException("length and height are different");
		}
		if (rotation % 90 != 0) {
			throw new IllegalArgumentException("rotation isn't divisible by 90");
		}

		this.rotation = rotation % 360;
	}

	/**
	 * Fills all empty space in the pane with the given {@code itemStack} and adds the given action
	 *
	 * @param itemStack The {@link ItemStack} to fill the empty space with
	 * @param action The action called whenever an interaction with the item happens
     * @param plugin the plugin that will be the owner of the created items
     * @see #fillWith(ItemStack, Consumer)
     * @since 0.1.0
	 */
	public void fillWith(@NotNull ItemStack itemStack, @Nullable Consumer<? super InventoryClickEvent> action,
                         @NotNull Plugin plugin) {
		//The non empty spots
		Set<Slot> locations = this.items.keySet();

		for (int y = 0; y < this.getHeight(); y++) {
			for (int x = 0; x < this.getLength(); x++) {
				boolean found = false;

				for (Slot location : locations) {
					if (location.getX(getLength()) == x && location.getY(getLength()) == y) {
						found = true;
						break;
					}
				}

				if (!found) {
					this.addItem(new GuiItem(itemStack, action, plugin), x, y);
				}
			}
		}
	}

    /**
     * Fills all empty space in the pane with the given {@code itemStack} and adds the given action
     *
     * @param itemStack The {@link ItemStack} to fill the empty space with
     * @param action The action called whenever an interaction with the item happens
     * @since 0.1.0
     */
    public void fillWith(@NotNull ItemStack itemStack, @Nullable Consumer<? super InventoryClickEvent> action) {
        fillWith(itemStack, action, JavaPlugin.getProvidingPlugin(StaticPane.class));
    }

	/**
	 * Fills all empty space in the pane with the given {@code itemStack}
	 *
	 * @param itemStack The {@link ItemStack} to fill the empty space with
     * @since 0.1.0
	 */
	public void fillWith(@NotNull ItemStack itemStack) {
		this.fillWith(itemStack, null);
	}

    /**
     * Gets the item located at the provided slot. If the provided slot is empty, this will return null. The slots are
     * checked based on their position without regard for their underlying definition. For example, if an item was added
     * with its slot specified as an x,y coordinate pair, but this method is invoked with a slot specified as an index,
     * this item may still be returned if the x,y coordinate pair and slot are at the same position, given the current
     * dimensions of the pane. If multiple items match the position indicated by the provided slot, any of those items
     * may be the result of this invocation.
     *
     * @param slot the slot of the item
     * @return the item at this position, or null if there is no such item
     * @since 0.1.0
     */
    @Nullable
    public GuiItem getItem(@NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        for (Map.Entry<Slot, GuiItem> entry : this.items.entrySet()) {
            Slot key = entry.getKey();

            if (key.getX(getLength()) == x && key.getY(getLength()) == y)
                return entry.getValue();
        }

        return null;
    }

	@NotNull
	public Collection<GuiItem> getItems() {
		return items.values();
	}

    /**
     * Gets all items by their corresponding slots. The slots correspond to the type they were added with. For example,
     * if the slot was specified as an x,y coordinate pair, the slot will also be specified as such a pair. The returned
     * map is unmodifiable.
     *
     * @return a map of all items by their slot
     * @since 0.1.0
     */
    @NotNull
    public Map<@NotNull Slot, @NotNull GuiItem> getSlottedItems() {
        return Collections.unmodifiableMap(this.items);
    }

    @Override
    public void clear() {
        items.clear();
    }

	@NotNull
	public Collection<Pane> getPanes() {
		return new HashSet<>();
	}

	@Override
	public void flipHorizontally(boolean flipHorizontally) {
		this.flipHorizontally = flipHorizontally;
	}

	@Override
	public void flipVertically(boolean flipVertically) {
		this.flipVertically = flipVertically;
	}

    @Override
	public int getRotation() {
		return rotation;
	}

    @Override
	public boolean isFlippedHorizontally() {
		return flipHorizontally;
	}

    @Override
	public boolean isFlippedVertically() {
		return flipVertically;
	}

	/**
	 * Loads an outline pane from a given element
	 *
	 * @param instance the instance class
	 * @param element the element
     * @param plugin the plugin that will be the owner of the udnerlying items
	 * @return the outline pane
     * @since 0.1.0
	 */
	@NotNull
	public static StaticPane load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Cycle button XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Cycle button XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        StaticPane staticPane = new StaticPane(length, height);

        Pane.load(staticPane, instance, element);
        Flippable.load(staticPane, element);
        Rotatable.load(staticPane, element);

        if (element.hasAttribute("populate"))
            return staticPane;

        NodeList childNodes = element.getChildNodes();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node item = childNodes.item(i);

            if (item.getNodeType() != Node.ELEMENT_NODE)
                continue;

            Element child = (Element) item;

            staticPane.addItem(GuiItem.loadItem(instance, child, plugin), Slot.deserialize(child));
        }

        return staticPane;
	}
}
