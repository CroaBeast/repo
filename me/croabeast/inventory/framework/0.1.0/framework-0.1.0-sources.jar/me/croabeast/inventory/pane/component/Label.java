package me.croabeast.inventory.pane.component;

import lombok.Getter;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.font.util.Font;
import me.croabeast.inventory.pane.*;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Slot;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;

import java.util.Collection;
import java.util.Collections;
import java.util.function.BiFunction;

/**
 * A label for displaying text.
 *
 * @since 0.1.0
 */
public class Label extends Pane {

    /**
     * The character set used for displaying the characters in this label
     */
    @NotNull
    @Getter
    private final Font font;

    /**
     * The text to be displayed
     */
    @NotNull
    @Getter
    private String text;

    /**
     * The pane used for displaying the label.
     */
    @NotNull
    private OutlinePane pane;

    /**
     * The plugin to be sed for creating items
     */
    @NotNull
    private final Plugin plugin;

    /**
     * Creates a new label
     *
     * @param length the length
     * @param height the height
     * @param priority the priority
     * @param font the character set
     * @param plugin the plugin that will be the owner for this label's items
     * @since 0.1.0
     */
    public Label(int length, int height, @NotNull Priority priority, @NotNull Font font, @NotNull Plugin plugin) {
        super(length, height);

        this.pane = new OutlinePane(length, height, priority);

        this.font = font;
        this.text = "";

        this.plugin = plugin;

        setPriority(priority);
    }

    /**
     * Creates a new label
     *
     * @param length the length
     * @param height the height
     * @param font the character set
     * @param plugin the plugin that will be the owner for this label's items
     * @since 0.1.0
     */
    public Label(int length, int height, @NotNull Font font, @NotNull Plugin plugin) {
        this(length, height, Priority.NORMAL, font, plugin);
    }

    /**
     * Creates a new label
     *
     * @param length the length
     * @param height the height
     * @param priority the priority
     * @param font the character set
     * @since 0.1.0
     */
    public Label(int length, int height, @NotNull Priority priority, @NotNull Font font) {
        this(length, height, priority, font, JavaPlugin.getProvidingPlugin(Label.class));
    }

    /**
     * Creates a new label
     *
     * @param length the length
     * @param height the height
     * @param font the character set
     * @since 0.1.0
     */
    public Label(int length, int height, @NotNull Font font) {
        this(length, height, Priority.NORMAL, font);
    }

    /**
     * Sets the text to be displayed in this label. If this label already had text, this text will be overwritten. The
     * specified processor will be called for each character that is part of the specified text. The provided character
     * will be the original character that was attempted to be shown - it is not subject to any transformations that may
     * be applied for finding a valid item corresponding to this character, such as capitalization changes.
     *
     * @param text the new text
     * @param processor processes each character before using them
     * @since 0.1.0
     */
    public void setText(@NotNull String text,
                        @NotNull BiFunction<? super @NotNull Character, ? super @NotNull ItemStack,
                                ? extends @NotNull GuiItem> processor) {
        this.text = text;

        clear();

        for (char character : text.toCharArray()) {
            ItemStack item = font.toItem(character);

            if (item == null)
                item = font.toItem(Character.toUpperCase(character));

            if (item == null)
                item = font.toItem(Character.toLowerCase(character));

            if (item == null)
                item = font.getDefaultItem();

            this.pane.addItem(processor.apply(character, item.clone()));
        }
    }

    /**
     * Sets the text to be displayed in this label. If this label already had text, this text will be overwritten.
     *
     * @param text the new text
     * @see #setText(String, BiFunction)
     * @since 0.1.0
     */
    public void setText(@NotNull String text) {
        setText(text, (character, item) -> new GuiItem(item, this.plugin));
    }

    @NotNull
    public Label copy() {
        Label label = new Label(getLength(), getHeight(), getPriority(), getFont(), this.plugin);

        label.setVisible(isVisible());
        label.onClick = onClick;

        label.pane = this.pane.copy();
        label.uuid = uuid;

        label.text = text;

        return label;
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        event.setCancelled(true);

        return this.pane.click(gui, guiComponent, event, slot);
    }

    @NotNull
    public GuiItemContainer display() {
        return this.pane.display();
    }

    @NotNull
    public Collection<GuiItem> getItems() {
        return this.pane.getItems();
    }

    @Override
    public void clear() {
        this.pane.clear();
    }

    @NotNull
    public Collection<Pane> getPanes() {
        return Collections.emptySet();
    }

    /**
     * Loads a label from a given element
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will be the owner of the underlying items
     * @return the percentage bar
     * @since 0.1.0
     */
    @NotNull
    public static Label load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Label XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Label XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        Font font = null;

        if (element.hasAttribute("font"))
            font = Font.fromName(element.getAttribute("font"));

        if (font == null)
            throw new XMLLoadException("Incorrect font specified for label");

        Label label = new Label(length, height, font, plugin);

        Pane.load(label, instance, element);

        if (element.hasAttribute("populate"))
            return label;

        if (element.hasAttribute("text"))
            label.setText(element.getAttribute("text"));

        return label;
    }
}
