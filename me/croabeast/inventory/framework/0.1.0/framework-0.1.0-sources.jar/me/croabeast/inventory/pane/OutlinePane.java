package me.croabeast.inventory.pane;

import lombok.Getter;
import lombok.Setter;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Mask;
import me.croabeast.inventory.pane.util.Slot;
import me.croabeast.inventory.util.GeometryUtil;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;

/**
 * A pane for items that should be outlined
 */
public class OutlinePane extends Pane implements Flippable, Orientable, Rotatable {

    /**
     * A set of items inside this pane
     */
    @NotNull
    @Getter
    private final List<GuiItem> items;

    /**
     * The orientation of the items in this pane
     */
    @NotNull
    @Getter
    @Setter
    private Orientation orientation;

    /**
     * The clockwise rotation of this pane in degrees
     */
    @Getter
    private int rotation;

    /**
     * The amount of empty spots in between each item
     */
    @Getter
    @Setter
    private int gap;

    /**
     * Whether the items should be repeated to fill the entire pane
     */
    @Setter
    private boolean repeat;

    /**
     * Whether the items should be flipped horizontally and/or vertically
     */
    private boolean flipHorizontally, flipVertically;

    /**
     * The alignment of this pane
     */
    @NotNull
    @Getter
    private Alignment alignment = Alignment.BEGIN;

    /**
     * The mask for this pane
     */
    @NotNull
    @Getter
    private Mask mask;

    /**
     * Creates a new outline pane
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @param priority the priority of the pane
     * @since 0.1.0
     */
    public OutlinePane(int length, int height, @NotNull Priority priority) {
        super(length, height, priority);

        this.items = new ArrayList<>(length * height);
        this.orientation = Orientation.HORIZONTAL;

        String[] mask = new String[height];
        StringBuilder maskString = new StringBuilder();

        for (int i = 0; i < length; i++) {
            maskString.append('1');
        }

        Arrays.fill(mask, maskString.toString());

        this.mask = new Mask(mask);
    }


    /**
     * Creates a new outline pane
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @since 0.1.0
     */
    public OutlinePane(int length, int height) {
        this(length, height, Priority.NORMAL);
    }

    @NotNull
    public GuiItemContainer display() {
        GuiItemContainer container = new GuiItemContainer(getLength(), getHeight());

        int itemIndex = 0;
        int gapCount = 0;

        int size;

        if (getOrientation() == Orientation.HORIZONTAL) {
            size = getHeight();
        } else if (getOrientation() == Orientation.VERTICAL) {
            size = getHeight();
        } else {
            throw new IllegalStateException("Unknown orientation '" + getOrientation() + "'");
        }

        for (int vectorIndex = 0; vectorIndex < size && getItems().size() > itemIndex; vectorIndex++) {
            boolean[] maskLine;

            if (getOrientation() == Orientation.HORIZONTAL) {
                maskLine = mask.getRow(vectorIndex);
            } else if (getOrientation() == Orientation.VERTICAL) {
                maskLine = mask.getColumn(vectorIndex);
            } else {
                throw new IllegalStateException("Unknown orientation '" + getOrientation() + "'");
            }

            int enabled = 0;

            for (boolean bool : maskLine) {
                if (bool)
                    enabled++;
            }

            GuiItem[] items;

            if (doesRepeat()) {
                items = new GuiItem[enabled];
            } else {
                int remainingPositions = gapCount + (getItems().size() - itemIndex - 1) * (getGap() + 1) + 1;

                items = new GuiItem[Math.min(enabled, remainingPositions)];
            }

            for (int index = 0; index < items.length; index++) {
                if (gapCount == 0) {
                    items[index] = getItems().get(itemIndex);

                    itemIndex++;

                    if (doesRepeat() && itemIndex >= getItems().size())
                        itemIndex = 0;

                    gapCount = getGap();
                } else {
                    items[index] = null;

                    gapCount--;
                }
            }

            int index;

            if (getAlignment() == Alignment.BEGIN) {
                index = 0;
            } else if (getAlignment() == Alignment.CENTER) {
                index = -((enabled - items.length) / 2);
            } else {
                throw new IllegalStateException("Unknown alignment '" + getAlignment() + "'");
            }

            for (int opposingVectorIndex = 0; opposingVectorIndex < maskLine.length; opposingVectorIndex++) {
                if (!maskLine[opposingVectorIndex])
                    continue;

                if (index >= 0 && index < items.length && items[index] != null) {
                    int x, y;

                    if (getOrientation() == Orientation.HORIZONTAL) {
                        x = opposingVectorIndex;
                        y = vectorIndex;
                    } else if (getOrientation() == Orientation.VERTICAL) {
                        x = vectorIndex;
                        y = opposingVectorIndex;
                    } else {
                        throw new IllegalStateException("Unknown orientation '" + getOrientation() + "'");
                    }

                    if (flipHorizontally)
                        x = getLength() - x - 1;

                    if (flipVertically)
                        y = getHeight() - y - 1;

                    Map.Entry<Integer, Integer> coordinates = GeometryUtil.processClockwiseRotation(x, y,
                            getLength(), getHeight(), rotation);

                    x = coordinates.getKey();
                    y = coordinates.getValue();

                    if (x >= 0 && x < getLength() && y >= 0 && y < getHeight()) {
                        GuiItem item = items[index];

                        if (item.isVisible())
                            container.setItem(item, x, y);
                    }
                }

                index++;
            }
        }

        return container;
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        //this isn't our item
        if (x < 0 || x >= getLength() || y < 0 || y >= getHeight())
            return false;

        callOnClick(event);

        ItemStack itemStack = event.getCurrentItem();

        if (itemStack == null)
            return false;

        GuiItem item = findMatchingItem(items, itemStack);

        if (item == null)
            return false;

        item.callAction(event);

        return true;
    }

    @NotNull
    public OutlinePane copy() {
        OutlinePane outlinePane = new OutlinePane(getLength(), getHeight(), getPriority());

        for (GuiItem item : items) {
            outlinePane.addItem(item.copy());
        }

        outlinePane.setVisible(isVisible());
        outlinePane.onClick = onClick;

        outlinePane.uuid = uuid;

        outlinePane.orientation = orientation;
        outlinePane.rotation = rotation;
        outlinePane.gap = gap;
        outlinePane.repeat = repeat;
        outlinePane.flipHorizontally = flipHorizontally;
        outlinePane.flipVertically = flipVertically;
        outlinePane.mask = mask;
        outlinePane.alignment = alignment;

        return outlinePane;
    }

    @Override
    public void setRotation(int rotation) {
        if (length != height)
            throw new UnsupportedOperationException("length and height are different");

        if (rotation % 90 != 0)
            throw new IllegalArgumentException("rotation isn't divisible by 90");

        this.rotation = rotation % 360;
    }

    /**
     * Adds a gui item in the specified index
     *
     * @param item the item to add
     * @param index the item's index
     */
    public void insertItem(@NotNull GuiItem item, int index) {
        items.add(index, item);
    }

    /**
     * Adds a gui item at the specific spot in the pane
     *
     * @param item the item to set
     */
    public void addItem(@NotNull GuiItem item) {
        items.add(item);
    }

    /**
     * Removes the specified item from the pane
     *
     * @param item the item to remove
     * @since 0.1.0
     */
    public void removeItem(@NotNull GuiItem item) {
        items.remove(item);
    }

    @Override
    public void clear() {
        items.clear();
    }

    /**
     * Applies a custom mask to this pane. This will throw an {@link IllegalArgumentException} when the mask's dimension
     * differs from this pane's dimension.
     *
     * @param mask the mask to apply to this pane
     * @throws IllegalArgumentException when the mask's dimension is incorrect
     * @since 0.1.0
     */
    public void applyMask(@NotNull Mask mask) {
        if (length != mask.getLength() || height != mask.getHeight())
            throw new IllegalArgumentException("Mask's dimension must be the same as the pane's dimension");

        this.mask = mask;
    }

    @Override
    public void setLength(int length) {
        super.setLength(length);

        applyMask(getMask().setLength(length));
    }

    @Override
    public void setHeight(int height) {
        super.setHeight(height);

        applyMask(getMask().setHeight(height));
    }

    /**
     * Aligns the pane in the way specified by the provided alignment.
     *
     * @param alignment the new alignment
     * @since 0.1.0
     */
    public void align(@NotNull Alignment alignment) {
        this.alignment = alignment;
    }

    @Override
    public void flipHorizontally(boolean flipHorizontally) {
        this.flipHorizontally = flipHorizontally;
    }

    @Override
    public void flipVertically(boolean flipVertically) {
        this.flipVertically = flipVertically;
    }

    @NotNull
    public Collection<Pane> getPanes() {
        return new HashSet<>();
    }

    /**
     * Gets whether this outline pane repeats itself
     *
     * @return true if this pane repeats, false otherwise
     */
    public boolean doesRepeat() {
        return repeat;
    }

    @Override
    public boolean isFlippedHorizontally() {
        return flipHorizontally;
    }

    @Override
    public boolean isFlippedVertically() {
        return flipVertically;
    }

    /**
     * Loads an outline pane from a given element
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will be the owner of the created items
     * @return the outline pane
     * @since 0.1.0
     */
    @NotNull
    public static OutlinePane load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Outline pane XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Outline pane XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        OutlinePane outlinePane = new OutlinePane(length, height);

        if (element.hasAttribute("gap")) {
            try {
                outlinePane.setGap(Integer.parseInt(element.getAttribute("gap")));
            } catch (NumberFormatException exception) {
                throw new XMLLoadException("Gap attribute is not an integer", exception);
            }
        }

        if (element.hasAttribute("repeat"))
            outlinePane.setRepeat(Boolean.parseBoolean(element.getAttribute("repeat")));

        if (element.hasAttribute("alignment")) {
            try {
                outlinePane.align(Alignment.valueOf(element.getAttribute("alignment").toUpperCase()));
            } catch (IllegalArgumentException exception) {
                throw new XMLLoadException("Alignment attribute is not a proper value", exception);
            }
        }

        Pane.load(outlinePane, instance, element);
        Flippable.load(outlinePane, element);
        Orientable.load(outlinePane, element);
        Rotatable.load(outlinePane, element);

        if (element.hasAttribute("populate"))
            return outlinePane;

        NodeList childNodes = element.getChildNodes();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node item = childNodes.item(i);

            if (item.getNodeType() != Node.ELEMENT_NODE)
                continue;

            if (item.getNodeName().equals("empty"))
                outlinePane.addItem(new GuiItem(new ItemStack(Material.AIR), plugin));
            else
                outlinePane.addItem(GuiItem.loadItem(instance, (Element) item, plugin));
        }

        return outlinePane;
    }

    /**
     * An enum containing different alignments that can be used on the outline pane.
     *
     * @since 0.1.0
     */
    public enum Alignment {

        /**
         * Aligns the items at the start of the pane.
         *
         * @since 0.1.0
         */
        BEGIN,

        /**
         * Aligns the items in the center of the pane. If there is no exact center, this will preference the left (for a
         * horizontal orientation) or the top (for a vertical orientation).
         *
         * @since 0.1.0
         */
        CENTER
    }
}
