package me.croabeast.inventory.exception;

import org.jetbrains.annotations.NotNull;

/**
 * An exception indicating that the provided version is not supported.
 *
 * @since 0.1.0
 */
public class UnsupportedVersionException extends RuntimeException {

    /**
     * Constructs the exception with a given message
     *
     * @param message the message to show
     * @since 0.1.0
     */
    public UnsupportedVersionException(@NotNull String message) {
        super(message);
    }
}
