package me.croabeast.inventory.pane;

import lombok.Getter;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Pattern;
import me.croabeast.inventory.pane.util.Slot;
import me.croabeast.inventory.util.GeometryUtil;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;

/**
 * A pattern pane allows you to specify a textual pattern and assign items to individual characters.
 *
 * @since 0.1.0
 */
public class PatternPane extends Pane implements Flippable, Rotatable {

    /**
     * The pattern of this pane.
     */
    @NotNull
    @Getter
    private Pattern pattern;

    /**
     * The bindings between the characters in the pattern and the gui item. Not every character in the pattern has to be
     * present in this map and this map may contain characters that are not present in the pattern.
     */
    @NotNull
    private final Map<Integer, GuiItem> bindings = new HashMap<>();

    /**
     * The amount of degrees this pane is rotated by. This will always be between [0,360) and a multiple of 90.
     */
    @Getter
    private int rotation;

    /**
     * Whether this pane is flipped horizontally.
     */
    @Getter
    private boolean flippedHorizontally;

    /**
     * Whether this pane is flipped vertically.
     */
    @Getter
    private boolean flippedVertically;

    /**
     * Constructs a new pattern pane.
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @param priority the priority of the pane
     * @param pattern the pattern of the pane
     * @throws IllegalArgumentException when the pane and pattern dimensions don't match
     * @since 0.1.0
     */
    public PatternPane(int length, int height, @NotNull Priority priority, @NotNull Pattern pattern) {
        super(length, height, priority);

        if (pattern.getLength() != length || pattern.getHeight() != height) {
            throw new IllegalArgumentException(
                    "Dimensions of the provided pattern do not match the dimensions of the pane"
            );
        }

        this.pattern = pattern;
    }

    /**
     * Constructs a new pattern pane, with no position.
     *
     * @param length the length of the pane
     * @param height the height of the pane
     * @param pattern the pattern of the pane
     * @throws IllegalArgumentException when the pane and pattern dimensions don't match
     * @since 0.1.0
     */
    public PatternPane(int length, int height, @NotNull Pattern pattern) {
        this(length, height, Priority.NORMAL, pattern);
    }

    @NotNull
    public GuiItemContainer display() {
        GuiItemContainer container = new GuiItemContainer(getLength(), getHeight());

        for (int x = 0; x < getLength(); x++) {
            for (int y = 0; y < getHeight(); y++) {
                GuiItem item = this.bindings.get(pattern.getCharacter(x, y));

                if (item == null || !item.isVisible())
                    continue;

                int newX = x, newY = y;

                if (isFlippedHorizontally())
                    newX = getLength() - x - 1;

                if (isFlippedVertically())
                    newY = getHeight() - y - 1;

                Map.Entry<Integer, Integer> coordinates = GeometryUtil.processClockwiseRotation(newX, newY, getLength(),
                    getHeight(), rotation);

                container.setItem(item, coordinates.getKey(), coordinates.getValue());
            }
        }

        return container;
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        //this isn't our item
        if (x < 0 || x >= getLength() || y < 0 || y >= getHeight())
            return false;

        callOnClick(event);

        ItemStack itemStack = event.getCurrentItem();

        if (itemStack == null)
            return false;

        GuiItem clickedItem = findMatchingItem(getItems(), itemStack);

        if (clickedItem == null)
            return false;

        clickedItem.callAction(event);

        return true;
    }

    @NotNull
    public PatternPane copy() {
        PatternPane patternPane = new PatternPane(getLength(), getHeight(), getPriority(), getPattern());

        patternPane.setVisible(isVisible());
        patternPane.onClick = onClick;

        patternPane.uuid = uuid;

        patternPane.rotation = rotation;
        patternPane.flippedHorizontally = flippedHorizontally;
        patternPane.flippedVertically = flippedVertically;

        return patternPane;
    }

    @Override
    public void setRotation(int rotation) {
        if (getLength() != getHeight())
            throw new IllegalArgumentException("Rotations can only be applied to square panes");

        if (rotation >= 0 && rotation % 90 != 0)
            throw new IllegalArgumentException("Rotation must be non-negative and be a multiple of 90");

        this.rotation = rotation % 360;
    }

    /**
     * {@inheritDoc}
     *
     * This only returns the items for which their binding also appears in the given pattern. An item bound to 'x',
     * where 'x' does not appear in the pattern will not be returned.
     *
     * @return the bounded and used items
     * @since 0.1.0
     */
    @NotNull
    public Collection<GuiItem> getItems() {
        Set<GuiItem> items = new HashSet<>();

        for (Map.Entry<Integer, GuiItem> binding : bindings.entrySet()) {
            if (pattern.contains(binding.getKey()))
                items.add(binding.getValue());
        }

        return Collections.unmodifiableCollection(items);
    }

    /**
     * Overrides the pattern set on this pane.
     *
     * @param pattern the new pattern to set
     * @throws IllegalArgumentException when the pane and pattern dimensions don't match
     * @since 0.1.0
     */
    public void setPattern(@NotNull Pattern pattern) {
        if (pattern.getLength() != getLength() || pattern.getHeight() != getHeight()) {
            throw new IllegalArgumentException(
                "Dimensions of the provided pattern do not match the dimensions of the pane"
            );
        }

        this.pattern = pattern;
    }

    @Override
    public void setHeight(int height) {
        super.setHeight(height);

        this.pattern = this.pattern.setHeight(height);
    }

    @Override
    public void setLength(int length) {
        super.setLength(length);

        this.pattern = this.pattern.setLength(length);
    }

    /**
     * Binds a character to a specific item or if the character was already bound, this overwrites the previously
     * binding with the provided one. To bind characters above the 16-bit range, see {@link #bindItem(int, GuiItem)}.
     *
     * @param character the character
     * @param item the item this represents
     * @since 0.1.0
     */
    public void bindItem(char character, @NotNull GuiItem item) {
        this.bindings.put((int) character, item);
    }

    /**
     * Binds a character to a specific item or if the character was already bound, this overwrites the previously
     * binding with the provided one.
     *
     * @param character the character
     * @param item the item this represents
     * @since 0.1.0
     * @see PatternPane#bindItem(char, GuiItem)
     */
    public void bindItem(int character, @NotNull GuiItem item) {
        this.bindings.put(character, item);
    }

    @Override
    public void clear() {
        this.bindings.clear();
    }

    @Override
    public void flipHorizontally(boolean flipHorizontally) {
        this.flippedHorizontally = flipHorizontally;
    }

    @Override
    public void flipVertically(boolean flipVertically) {
        this.flippedVertically = flipVertically;
    }

    @NotNull
    public Collection<Pane> getPanes() {
        return Collections.emptySet();
    }

    /**
     * Loads a pattern pane from a given element
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will own the underlying items
     * @return the pattern pane
     * @since 0.1.0
     */
    @NotNull
    public static PatternPane load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        NodeList childNodes = element.getChildNodes();

        Pattern pattern = null;
        Map<Integer, GuiItem> bindings = new HashMap<>();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node item = childNodes.item(i);

            if (item.getNodeType() != Node.ELEMENT_NODE)
                continue;

            Element child = (Element) item;
            String name = item.getNodeName();

            if (name.equals("pattern")) {
                pattern = Pattern.load(child);
            } else if (name.equals("binding")) {
                if (!child.hasAttribute("char"))
                    throw new XMLLoadException("Tag binding is missing char attribute");

                String character = child.getAttribute("char");

                if (character.codePointCount(0, character.length()) != 1)
                    throw new XMLLoadException("Char attribute doesn't have one character");

                NodeList children = child.getChildNodes();
                GuiItem guiItem = null;

                for (int index = 0; index < children.getLength(); index++) {
                    Node guiItemNode = children.item(index);

                    if (guiItemNode.getNodeType() != Node.ELEMENT_NODE)
                        continue;

                    if (guiItem != null)
                        throw new XMLLoadException("Binding has multiple inner tags, one expected");

                    guiItem = GuiItem.loadItem(instance, (Element) guiItemNode, plugin);
                }

                //guaranteed to only be a single code point
                bindings.put(character.codePoints().toArray()[0], guiItem);
            } else {
                throw new XMLLoadException("Unknown tag " + name + " in pattern pane");
            }
        }

        if (pattern == null)
            throw new XMLLoadException("Pattern pane doesn't have a pattern");

        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Pattern pane XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Pattern pane XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        PatternPane patternPane = new PatternPane(length, height, pattern);

        Pane.load(patternPane, instance, element);
        Flippable.load(patternPane, element);
        Rotatable.load(patternPane, element);

        if (!element.hasAttribute("populate")) {
            for (Map.Entry<Integer, GuiItem> entry : bindings.entrySet()) {
                patternPane.bindItem(entry.getKey(), entry.getValue());
            }
        }

        return patternPane;
    }
}
