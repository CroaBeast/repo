package me.croabeast.inventory.gui.type;

import lombok.Getter;
import me.croabeast.inventory.HumanEntityCache;
import me.croabeast.inventory.adventure.TextHolder;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.gui.type.util.InventoryBased;
import me.croabeast.inventory.gui.type.util.NamedGui;
import me.croabeast.inventory.pane.Pane;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/**
 * Represents a gui in the form of a dropper
 *
 * @since 0.1.0
 */
public class DropperGui extends NamedGui implements InventoryBased {

    /**
     * Represents the gui component for the contents
     */
    @NotNull
    @Getter
    private GuiComponent contentsComponent = new GuiComponent(3, 3);

    /**
     * Represents the gui component for the player inventory
     */
    @NotNull
    @Getter
    private GuiComponent playerGuiComponent = new GuiComponent(9, 4);

    /**
     * Constructs a new GUI
     *
     * @param title the title/name of this gui.
     * @since 0.1.0
     */
    public DropperGui(@NotNull String title) {
        super(title);
    }

    /**
     * Constructs a new GUI
     *
     * @param title the title/name of this gui.
     * @since 0.1.0
     */
    public DropperGui(@NotNull TextHolder title) {
        super(title);
    }

    /**
     * Constructs a new dropper gui for the given {@code plugin}.
     *
     * @param title the title/name of this gui.
     * @param plugin the owning plugin of this gui
     * @see #DropperGui(String)
     * @since 0.1.0
     */
    public DropperGui(@NotNull String title, @NotNull Plugin plugin) {
        super(title, plugin);
    }

    /**
     * Constructs a new dropper gui for the given {@code plugin}.
     *
     * @param title the title/name of this gui.
     * @param plugin the owning plugin of this gui
     * @see #DropperGui(TextHolder)
     * @since 0.1.0
     */
    public DropperGui(@NotNull TextHolder title, @NotNull Plugin plugin) {
        super(title, plugin);
    }

    @Override
    public void update() {
        super.updating = true;

        if (isDirty()) {
            Inventory oldInventory = this.inventory;
            this.inventory = createInventory();

            if (oldInventory != null) {
                for (HumanEntity viewer : new ArrayList<>(oldInventory.getViewers())) {
                    viewer.openInventory(this.inventory);
                }
            }

            markChanges();
        }

        getInventory().clear();

        getContentsComponent().display(getInventory(), 0);
        getPlayerGuiComponent().display();

        for (HumanEntity viewer : getViewers()) {
            ItemStack cursor = viewer.getItemOnCursor();
            viewer.setItemOnCursor(new ItemStack(Material.AIR));

            populateBottomInventory(viewer);

            viewer.setItemOnCursor(cursor);
        }

        if (!super.updating)
            throw new AssertionError("Gui#isUpdating became false before Gui#update finished");

        super.updating = false;
    }

    @NotNull
    public Iterable<? extends GuiItem> getItems() {
        Collection<@NotNull GuiItem> items = new HashSet<>();

        for (Pane pane : getContentsComponent().getPanes()) {
            items.addAll(pane.getItems());
        }

        for (Pane pane : getPlayerGuiComponent().getPanes()) {
            items.addAll(pane.getItems());
        }

        return items;
    }

    @Override
    public void show(@NotNull HumanEntity humanEntity) {
        if (isDirty())
            update();

        populateBottomInventory(humanEntity);

        humanEntity.openInventory(getInventory());
    }

    /**
     * Populates the inventory of the {@link HumanEntity} if needed.
     *
     * @param humanEntity the human entity
     * @since 0.1.0
     */
    private void populateBottomInventory(@NotNull HumanEntity humanEntity) {
        if (getPlayerGuiComponent().hasItem()) {
            HumanEntityCache humanEntityCache = getHumanEntityCache();

            if (!humanEntityCache.contains(humanEntity))
                humanEntityCache.storeAndClear(humanEntity);

            getPlayerGuiComponent().placeItems(humanEntity.getInventory(), 0);
        }
    }

    @NotNull
    public DropperGui copy() {
        DropperGui gui = new DropperGui(getTitleHolder(), super.plugin);

        gui.contentsComponent = contentsComponent.copy();
        gui.playerGuiComponent = this.playerGuiComponent.copy();

        gui.setOnTopClick(this.onTopClick);
        gui.setOnBottomClick(this.onBottomClick);
        gui.setOnGlobalClick(this.onGlobalClick);
        gui.setOnOutsideClick(this.onOutsideClick);
        gui.setOnClose(this.onClose);

        return gui;
    }

    @Override
    public void click(@NotNull InventoryClickEvent event) {
        int rawSlot = event.getRawSlot();

        if (rawSlot >= 0 && rawSlot <= 8) {
            getContentsComponent().click(this, event, rawSlot);
        } else {
            getPlayerGuiComponent().click(this, event, rawSlot - 9);
        }
    }

    @NotNull
    public Inventory getInventory() {
        if (this.inventory == null)
            this.inventory = createInventory();

        return inventory;
    }

    @Override
    public boolean isPlayerInventoryUsed() {
        return getPlayerGuiComponent().hasItem();
    }

    @NotNull
    public Inventory createInventory() {
        Inventory inventory = getTitleHolder().asInventoryTitle(this, InventoryType.DROPPER);

        addInventory(inventory, this);

        return inventory;
    }

    @Override
    public int getViewerCount() {
        return getInventory().getViewers().size();
    }

    @NotNull
    public List<HumanEntity> getViewers() {
        return new ArrayList<>(getInventory().getViewers());
    }

    /**
     * Loads a dropper gui from an XML file.
     *
     * @param instance the instance on which to reference fields and methods
     * @param inputStream the input stream containing the XML data
     * @param plugin the plugin that will be the owner of the created gui
     * @return the loaded dropper gui
     * @see #load(Object, InputStream)
     * @since 0.1.0
     */
    @Nullable
    public static DropperGui load(@NotNull Object instance, @NotNull InputStream inputStream, @NotNull Plugin plugin) {
        try {
            Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputStream);
            Element documentElement = document.getDocumentElement();

            documentElement.normalize();

            return load(instance, documentElement, plugin);
        } catch (SAXException | ParserConfigurationException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Loads a dropper gui from the specified element, applying code references to the provided instance.
     *
     * @param instance the instance on which to reference fields and methods
     * @param element the element to load the gui from
     * @param plugin the plugin that will be the owner of the created gui
     * @return the loaded dropper gui
     * @see #load(Object, Element)
     * @since 0.1.0
     */
    @NotNull
    public static DropperGui load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("title"))
            throw new XMLLoadException("Provided XML element's gui tag doesn't have the mandatory title attribute set");

        DropperGui dropperGui = new DropperGui(element.getAttribute("title"), plugin);
        dropperGui.initializeOrThrow(instance, element);

        if (element.hasAttribute("populate"))
            return dropperGui;

        NodeList childNodes = element.getChildNodes();

        for (int index = 0; index < childNodes.getLength(); index++) {
            Node item = childNodes.item(index);

            if (item.getNodeType() != Node.ELEMENT_NODE)
                continue;

            Element componentElement = (Element) item;

            if (!componentElement.getTagName().equalsIgnoreCase("component"))
                throw new XMLLoadException("Gui element contains non-component tags");

            if (!componentElement.hasAttribute("name"))
                throw new XMLLoadException("Component tag does not have a name specified");

            GuiComponent component;

            switch (componentElement.getAttribute("name")) {
                case "contents":
                    component = dropperGui.getContentsComponent();
                    break;
                case "player-inventory":
                    component = dropperGui.getPlayerGuiComponent();
                    break;
                default:
                    throw new XMLLoadException("Unknown component name");
            }

            component.load(instance, componentElement, plugin);
        }

        return dropperGui;
    }

    /**
     * Loads a dropper gui from an XML file.
     *
     * @param instance the instance on which to reference fields and methods
     * @param inputStream the input stream containing the XML data
     * @return the loaded dropper gui
     * @since 0.1.0
     */
    @Nullable
    public static DropperGui load(@NotNull Object instance, @NotNull InputStream inputStream) {
        return load(instance, inputStream, JavaPlugin.getProvidingPlugin(DropperGui.class));
    }

    /**
     * Loads a dropper gui from the specified element, applying code references to the provided instance.
     *
     * @param instance the instance on which to reference fields and methods
     * @param element the element to load the gui from
     * @return the loaded dropper gui
     * @since 0.1.0
     */
    @NotNull
    public static DropperGui load(@NotNull Object instance, @NotNull Element element) {
        return load(instance, element, JavaPlugin.getProvidingPlugin(DropperGui.class));
    }
}
