package me.croabeast.inventory.pane.component;

import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.pane.Pane;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Slot;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;
import java.util.stream.Collectors;

/**
 * A button for cycling between different options
 *
 * @since 0.1.0
 */
public class CycleButton extends Pane {

    /**
     * The list of pane used for display
     */
    private final List<Pane> panes = new ArrayList<>();

    /**
     * The current position of the cycle button
     */
    private int position = 0;

    /**
     * Creates a new cycle button
     *
     * @param length the length of the button
     * @param height the height of the button
     * @param priority the priority of the button
     * @since 0.1.0
     */
    public CycleButton(int length, int height, @NotNull Priority priority) {
        super(length, height, priority);
    }

    /**
     * Creates a new cycle button
     *
     * @param length the length of the button
     * @param height the height of the button
     * @since 0.1.0
     */
    public CycleButton(int length, int height) {
        super(length, height);
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        //this isn't our item
        if (x < 0 || x >= getLength() || y < 0 || y >= getHeight())
            return false;

        int previousPosition = position;

        position++;

        if (position == panes.size())
            position = 0;

        callOnClick(event);

        //use the previous position, since that will have the pane we clicked on
        panes.get(previousPosition).click(gui, guiComponent, event, slot);

        gui.update();

        return true;
    }

    @NotNull
    public GuiItemContainer display() {
        GuiItemContainer container = new GuiItemContainer(getLength(), getHeight());

        container.apply(this.panes.get(this.position).display(), 0, 0);

        return container;
    }

    @NotNull
    public CycleButton copy() {
        CycleButton cycleButton = new CycleButton(getLength(), getHeight(), getPriority());

        for (Pane pane : panes) {
            cycleButton.addPane(pane);
        }

        cycleButton.setVisible(isVisible());
        cycleButton.onClick = onClick;

        cycleButton.position = position;

        cycleButton.uuid = uuid;

        return cycleButton;
    }

    @NotNull
    public Collection<GuiItem> getItems() {
        return getPanes().stream().flatMap(pane -> pane.getItems().stream()).collect(Collectors.toList());
    }

    /**
     * Adds a pane to the current list of options
     *
     * @param index the index to insert the pane at
     * @param pane the pane to add
     * @since 0.1.0
     */
    public void addPane(int index, @NotNull Pane pane) {
        panes.add(index, pane);
    }

    /**
     * Adds a pane to the current list of options
     *
     * @param pane the pane to add
     * @since 0.1.0
     */
    public void addPane(@NotNull Pane pane) {
        panes.add(pane);
    }

    @Override
    public void clear() {
        panes.clear();
    }

    @NotNull
    public Collection<Pane> getPanes() {
        return panes;
    }

    /**
     * Cycles through one option, making it go to the next one
     *
     * @since 0.1.0
     */
    public void cycle() {
        position++;
    }

    /**
     * Loads a cycle button from a given element
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will be the owner of the underlying items
     * @return the cycle button
     * @since 0.1.0
     */
    @NotNull
    public static CycleButton load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Cycle button XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Cycle button XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        CycleButton cycleButton = new CycleButton(length, height);

        Pane.load(cycleButton, instance, element);

        if (element.hasAttribute("populate"))
            return cycleButton;

        NodeList childNodes = element.getChildNodes();

        for (int j = 0; j < childNodes.getLength(); j++) {
            Node pane = childNodes.item(j);

            if (pane.getNodeType() != Node.ELEMENT_NODE)
                continue;

            cycleButton.addPane(Gui.loadPane(instance, pane, plugin));
        }

        return cycleButton;
    }
}
