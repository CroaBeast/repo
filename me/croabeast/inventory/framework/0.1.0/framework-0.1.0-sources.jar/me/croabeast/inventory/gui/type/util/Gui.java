package me.croabeast.inventory.gui.type.util;

import lombok.Getter;
import lombok.Setter;
import me.croabeast.inventory.HumanEntityCache;
import me.croabeast.inventory.annotation.exception.InvalidParametersException;
import me.croabeast.inventory.annotation.exception.MultipleAnnotationsException;
import me.croabeast.inventory.annotation.CloseHandler;
import me.croabeast.inventory.annotation.click.BottomClickHandler;
import me.croabeast.inventory.annotation.click.GlobalClickHandler;
import me.croabeast.inventory.annotation.click.OutsideClickHandler;
import me.croabeast.inventory.annotation.click.TopClickHandler;
import me.croabeast.inventory.annotation.drag.BottomDragHandler;
import me.croabeast.inventory.annotation.drag.GlobalDragHandler;
import me.croabeast.inventory.annotation.drag.TopDragHandler;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.gui.GuiListener;
import me.croabeast.inventory.gui.type.*;
import me.croabeast.inventory.pane.*;
import me.croabeast.inventory.pane.component.*;
import me.croabeast.inventory.util.TriFunction;
import me.croabeast.inventory.util.XMLUtil;
import me.croabeast.inventory.util.version.Version;
import org.bukkit.Bukkit;
import org.bukkit.entity.HumanEntity;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.logging.Level;

/**
 * The base class of all GUIs
 */
public abstract class Gui {

    /**
     * The plugin that owns this gui
     */
    @NotNull
    protected final Plugin plugin;

    /**
     * The inventory of this gui
     */
    protected Inventory inventory;

    /**
     * A player cache for storing player's inventories
     */
    @NotNull
    @Getter
    protected final HumanEntityCache humanEntityCache = new HumanEntityCache();

    /**
     * The consumer that will be called once a players clicks in the top-half of the gui
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryClickEvent> onTopClick;

    /**
     * The consumer that will be called once a players clicks in the bottom-half of the gui
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryClickEvent> onBottomClick;

    /**
     * The consumer that will be called once a players clicks in the gui or in their inventory
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryClickEvent> onGlobalClick;

    /**
     * The consumer that will be called once a player clicks outside of the gui screen
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryClickEvent> onOutsideClick;

    /**
     * The consumer that will be called once a player drags in the top-half of the gui
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryDragEvent> onTopDrag;

    /**
     * The consumer that will be called once a player drags in the bottom-half of the gui
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryDragEvent> onBottomDrag;

    /**
     * The consumer that will be called once a player drags in the gui or their inventory
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryDragEvent> onGlobalDrag;

    /**
     * The consumer that will be called once a player closes the gui
     */
    @Nullable
    @Setter
    protected Consumer<? super InventoryCloseEvent> onClose;

    /**
     * Whether this gui is updating (as invoked by {@link #update()}), true if this is the case, false otherwise. This
     * is used to indicate that inventory close events due to updating should be ignored.
     */
    @Getter
    protected boolean updating = false;

    /**
     * Whether the gui is dirty i.e., has changed. Dirty by default since it won't have been updated after its creation.
     */
    @Getter
    protected boolean dirty = true;

    /**
     * The parent gui. This gui will be navigated to once a player closes this gui. If this is null, the player will not
     * be redirected to another gui once they close this gui.
     */
    @Nullable
    @Setter
    private Gui parent;

    /**
     * The pane mapping which will allow users to register their own panes to be used in XML files
     */
    @NotNull
    private static final Map<String, TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>>
        PANE_MAPPINGS = new HashMap<>();

    /**
     * The gui mappings which determine which gui type belongs to which identifier
     */
    @NotNull
    private static final Map<String, TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>>
        GUI_MAPPINGS = new HashMap<>();

    /**
     * A map containing all the annotations and their associated actions for click handlers.
     */
    @NotNull
    private static final Map<Class<? extends Annotation>,
            BiConsumer<? super Gui, Consumer<? super InventoryClickEvent>>> CLICK_ANNOTATIONS = new HashMap<>();

    /**
     * A map containing all the annotations and their associated actions for drag handlers.
     */
    @NotNull
    private static final Map<Class<? extends Annotation>,
            BiConsumer<? super Gui, Consumer<? super InventoryDragEvent>>> DRAG_ANNOTATIONS = new HashMap<>();

    /**
     * A map containing all the annotations and their associated actions for close handlers.
     */
    @NotNull
    private static final Map<Class<? extends Annotation>,
            BiConsumer<? super Gui, Consumer<? super InventoryCloseEvent>>> CLOSE_ANNOTATIONS = new HashMap<>();

    /**
     * A map containing the relations between inventories and their respective gui. This is needed because Bukkit and
     * Spigot ignore inventory holders for beacons, brewing stands, dispensers, droppers, furnaces and hoppers. The
     * inventory holder for beacons is already being set properly via NMS, but this contains the other inventory types.
     */
    @NotNull
    private static final Map<Inventory, WeakReference<Gui>> GUI_INVENTORIES = new WeakHashMap<>();

    /**
     * Whether listeners have ben registered by some gui
     */
    private static boolean hasRegisteredListeners;

    /**
     * Constructs a new gui with the provided plugin.
     *
     * @param plugin the plugin
     * @since 0.1.0
     */
    public Gui(@NotNull Plugin plugin) {
        this.plugin = plugin;

        if (!hasRegisteredListeners) {
            /*This throws an exception if the version is unsupported. We want this thrown if our version is unsupported,
              to prevent people opening guis that do not behave correctly. */
            //noinspection ResultOfMethodCallIgnored
            Version.getVersion();

            Bukkit.getPluginManager().registerEvents(new GuiListener(plugin), plugin);

            hasRegisteredListeners = true;
        }

        processAnnotations();
    }

    /**
     * Shows a gui to a player
     *
     * @param humanEntity the human entity to show the gui to
     */
    public abstract void show(@NotNull HumanEntity humanEntity);

    /**
     * Makes a copy of this gui and returns it. This makes a deep copy of the gui. This entails that the underlying
     * panes will be copied as per their {@link Pane#copy} and miscellaneous data will be copied. The copy of this gui,
     * will however have no viewers even if this gui currently has viewers. With this, cache data for viewers will also
     * be non-existent for the copied gui. The original owning plugin of the gui is preserved, but the plugin will not
     * be deeply copied. The returned gui will never be reference equal to the current gui.
     *
     * @return a copy of the gui
     * @since 0.1.0
     */
    @NotNull
    public abstract Gui copy();

    /**
     * This should delegate the provided inventory click event to the right pane, which can then handle this click event
     * further. This should not call any internal click handlers, since those will already have been activated.
     *
     * @param event the event to delegate
     * @since 0.1.0
     */
    public abstract void click(@NotNull InventoryClickEvent event);

    /**
     * Gets whether the player inventory is currently in use. This means whether the player inventory currently has an
     * item in it.
     *
     * @return true if the player inventory is occupied, false otherwise
     * @since 0.1.0
     */
    public abstract boolean isPlayerInventoryUsed();

    /**
     * Gets the count of {@link HumanEntity} instances that are currently viewing this GUI.
     *
     * @return the count of viewers
     * @since 0.1.0
     */
    public abstract int getViewerCount();

    /**
     * Gets a mutable snapshot of the current {@link HumanEntity} viewers of this GUI.
     * This is a snapshot (copy) and not a view, therefore modifications aren't visible.
     *
     * @return a snapshot of the current viewers
     * @see #getViewerCount()
     * @since 0.1.0
     */
    @NotNull
    public abstract List<HumanEntity> getViewers();

    /**
     * Update the gui for everyone
     */
    public abstract void update();

    /**
     * Gets all the {@link GuiItem} instances in this gui.
     *
     * @return all gui items
     * @since 0.1.0
     */
    @NotNull
    public abstract Iterable<? extends GuiItem> getItems();

    /**
     * Adds the specified inventory and gui, so we can properly intercept clicks.
     *
     * @param inventory the inventory for the specified gui
     * @param gui the gui belonging to the specified inventory
     * @since 0.1.0
     */
    protected void addInventory(@NotNull Inventory inventory, @NotNull Gui gui) {
        GUI_INVENTORIES.put(inventory, new WeakReference<>(gui));
    }

    /**
     * Gets a gui from the specified inventory. Only guis of type beacon, brewing stand, dispenser, dropper, furnace and
     * hopper can be retrieved.
     *
     * @param inventory the inventory to get the gui from
     * @return the gui or null if the inventory doesn't have an accompanying gui
     * @since 0.1.0
     */
    @Nullable
    public static Gui getGui(@NotNull Inventory inventory) {
        WeakReference<Gui> reference = GUI_INVENTORIES.get(inventory);

        if (reference == null)
            return null;

        Gui gui = reference.get();

        if (gui == null)
            GUI_INVENTORIES.remove(inventory, reference);

        return gui;
    }

    /**
     * Loads a Gui from a given input stream.
     *
     * @param instance the class instance for all reflection lookups
     * @param inputStream the file
     * @return the gui or null if the loading failed
     * @throws XMLLoadException if loading could not finish successfully, due to e.g., a malformed file
     * @see #load(Object, InputStream)
     * @since 0.1.0
     */
    @Nullable
    public static Gui load(@NotNull Object instance, @NotNull InputStream inputStream, @NotNull Plugin plugin) {
        try {
            Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputStream);
            Element documentElement = document.getDocumentElement();

            documentElement.normalize();

            if (!documentElement.hasAttribute("type"))
                throw new XMLLoadException("Type attribute must be specified when loading via Gui.load");

            String type = documentElement.getAttribute("type");
            TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui> mapping = GUI_MAPPINGS
                    .get(type);

            if (mapping == null)
                throw new XMLLoadException("Type attribute '" + type + "' is invalid");

            return mapping.apply(instance, documentElement, plugin);
        } catch (SAXException | ParserConfigurationException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Loads a Gui from a given input stream.
     * Returns null instead of throwing an exception in case of a failure.
     *
     * @param instance the class instance for all reflection lookups
     * @param inputStream the file
     * @return the gui or null if the loading failed
     * @throws XMLLoadException if loading could not finish successfully, due to e.g., a malformed file
     */
    @Nullable
    public static Gui load(@NotNull Object instance, @NotNull InputStream inputStream) {
        return load(instance, inputStream, JavaPlugin.getProvidingPlugin(Gui.class));
    }

    /**
     * Initializes standard fields from a Gui from a given input stream.
     * Throws a {@link RuntimeException} instead of returning null in case of a failure.
     *
     * @param instance the class instance for all reflection lookups
     * @param element the gui element
     * @see #load(Object, InputStream)
     */
     protected void initializeOrThrow(@NotNull Object instance, @NotNull Element element) {
        if (element.hasAttribute("field"))
            XMLUtil.loadFieldAttribute(instance, element, this);

        if (element.hasAttribute("onTopClick")) {
            setOnTopClick(XMLUtil.loadOnEventAttribute(instance,
                element, InventoryClickEvent.class, "onTopClick"));
        }

        if (element.hasAttribute("onBottomClick")) {
            setOnBottomClick(XMLUtil.loadOnEventAttribute(instance,
                element, InventoryClickEvent.class, "onBottomClick"));
        }

        if (element.hasAttribute("onGlobalClick")) {
            setOnGlobalClick(XMLUtil.loadOnEventAttribute(instance,
                element, InventoryClickEvent.class, "onGlobalClick"));
        }

        if (element.hasAttribute("onOutsideClick")) {
            setOnOutsideClick(XMLUtil.loadOnEventAttribute(instance,
                element, InventoryClickEvent.class, "onOutsideClick"));
        }

         if (element.hasAttribute("onTopDrag")) {
             setOnTopDrag(XMLUtil.loadOnEventAttribute(instance,
                 element, InventoryDragEvent.class, "onTopDrag"));
         }

         if (element.hasAttribute("onBottomDrag")) {
             setOnBottomDrag(XMLUtil.loadOnEventAttribute(instance,
                 element, InventoryDragEvent.class, "onBottomDrag"));
         }

         if (element.hasAttribute("onGlobalDrag")) {
             setOnGlobalDrag(XMLUtil.loadOnEventAttribute(instance,
                 element, InventoryDragEvent.class, "onGlobalDrag"));
         }

        if (element.hasAttribute("onClose")) {
            setOnClose(XMLUtil.loadOnEventAttribute(instance,
                element, InventoryCloseEvent.class, "onClose"));
        }

        if (element.hasAttribute("populate"))
            XMLUtil.invokeMethod(instance, element.getAttribute("populate"), this, Gui.class);
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnTopClick(Consumer)},
     * so the consumer that should be called whenever this gui is clicked in.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnTopClick(@NotNull InventoryClickEvent event) {
        callCallback(onTopClick, event, "onTopClick");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnBottomClick(Consumer)},
     * so the consumer that should be called whenever the inventory is clicked in.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnBottomClick(@NotNull InventoryClickEvent event) {
        callCallback(onBottomClick, event, "onBottomClick");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnGlobalClick(Consumer)},
     * so the consumer that should be called whenever this gui or inventory is clicked in.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnGlobalClick(@NotNull InventoryClickEvent event) {
        callCallback(onGlobalClick, event, "onGlobalClick");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnOutsideClick(Consumer)},
     * so the consumer that should be called whenever a player clicks outside the gui.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnOutsideClick(@NotNull InventoryClickEvent event) {
        callCallback(onOutsideClick, event, "onOutsideClick");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnTopDrag(Consumer)},
     * so the consumer that should be called whenever this gui's top half is dragged in.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnTopDrag(@NotNull InventoryDragEvent event) {
        callCallback(onTopDrag, event, "onTopDrag");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnBottomDrag(Consumer)},
     * so the consumer that should be called whenever the inventory is dragged in.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnBottomDrag(@NotNull InventoryDragEvent event) {
        callCallback(onBottomDrag, event, "onBottomDrag");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnGlobalDrag(Consumer)},
     * so the consumer that should be called whenever this gui or inventory is dragged in.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnGlobalDrag(@NotNull InventoryDragEvent event) {
        callCallback(onGlobalDrag, event, "onGlobalDrag");
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnClose(Consumer)},
     * so the consumer that should be called whenever this gui is closed.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     * @since 0.1.0
     */
    public void callOnClose(@NotNull InventoryCloseEvent event) {
        callCallback(onClose, event, "onClose");
    }

    /**
     * Calls the specified consumer (if it's not null) with the specified parameter,
     * catching and logging all exceptions it might throw.
     *
     * @param callback the consumer to call if it isn't null
     * @param event the value the consumer should accept
     * @param callbackName the name of the action, used for logging
     * @param <T> the type of the value the consumer is accepting
     */
    protected <T extends InventoryEvent> void callCallback(@Nullable Consumer<? super T> callback,
            @NotNull T event, @NotNull String callbackName) {
        if (callback == null)
            return;

        try {
            callback.accept(event);
        } catch (Throwable t) {
            String message = "Exception while handling " + callbackName;
            if (event instanceof InventoryClickEvent) {
                InventoryClickEvent clickEvent = (InventoryClickEvent) event;
                message += ", slot=" + clickEvent.getSlot();
            }

            this.plugin.getLogger().log(Level.SEVERE, message, t);
        }
    }

    /**
     * The parent gui will be shown to the specified {@link HumanEntity}. If no parent gui is set, then this method will
     * silently do nothing.
     *
     * @param humanEntity the human entity to redirect
     * @since 0.1.0
     */
    public void navigateToParent(@NotNull HumanEntity humanEntity) {
        if (this.parent == null)
            return;

        this.parent.show(humanEntity);
    }

    /**
     * Marks that the changes present here have been accepted. This sets dirty to false. If dirty was already false,
     * this will do nothing.
     *
     * @since 0.1.0
     */
    public void markChanges() {
        this.dirty = false;
    }

    /**
     * Registers a property that can be used inside an XML file to add additional new properties.
     *
     * @param attributeName the name of the property. This is the same name you'll be using to specify the property
     *                      type in the XML file.
     * @param function how the property should be processed. This converts the raw text input from the XML node value
     *                 into the correct object type.
     * @throws IllegalArgumentException when a property with this name is already registered.
     */
    public static void registerProperty(@NotNull String attributeName, @NotNull Function<? super String, ?> function) {
        GuiItem.registerProperty(attributeName, function);
    }

    /**
     * Registers a name that can be used inside an XML file to add custom panes
     *
     * @param name the name of the pane to be used in the XML file
     * @param triFunction how the pane loading should be processed
     * @throws IllegalArgumentException when a pane with this name is already registered
     * @see #registerPane(String, BiFunction)
     * @since 0.1.0
     */
    public static void registerPane(@NotNull String name,
                                    @NotNull TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane> triFunction) {
        if (PANE_MAPPINGS.containsKey(name))
            throw new IllegalArgumentException("pane name '" + name + "' is already registered");

        PANE_MAPPINGS.put(name, triFunction);
    }

    /**
     * Registers a name that can be used inside an XML file to add custom panes
     *
     * @param name the name of the pane to be used in the XML file
     * @param biFunction how the pane loading should be processed
     * @throws IllegalArgumentException when a pane with this name is already registered
     */
    public static void registerPane(@NotNull String name,
                                    @NotNull BiFunction<? super Object, ? super Element, ? extends Pane> biFunction) {
        registerPane(name, (object, element, plugin) -> biFunction.apply(object, element));
    }

    /**
     * Registers a type that can be used inside an XML file to specify the gui type
     *
     * @param name the name of the type of gui to be used in an XML file
     * @param triFunction how the gui creation should be processed
     * @throws IllegalArgumentException when a gui type with this name is already registered
     * @since 0.1.0
     */
    public static void registerGui(@NotNull String name,
                                   @NotNull TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui> triFunction) {
        if (GUI_MAPPINGS.containsKey(name))
            throw new IllegalArgumentException("Gui name '" + name + "' is already registered");

        GUI_MAPPINGS.put(name, triFunction);
    }

    /**
     * Loads a pane by the given instance and node
     *
     * @param instance the instance
     * @param node the node
     * @param plugin the plugin to load the pane with
     * @return the pane
     * @throws XMLLoadException if the name of the node does not correspond to a valid pane.
     * @since 0.1.0
     */
    @NotNull
    public static Pane loadPane(@NotNull Object instance, @NotNull Node node, @NotNull Plugin plugin) {
        String name = node.getNodeName();
        TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane> mapping = PANE_MAPPINGS.get(name);

        if (mapping == null)
            throw new XMLLoadException("Pane '" + name + "' is not registered or does not exist");

        return mapping.apply(instance, (Element) node, plugin);
    }

    /**
     * Loads a pane by the given instance and node
     *
     * @param instance the instance
     * @param node the node
     * @return the pane
     */
    @NotNull
    public static Pane loadPane(@NotNull Object instance, @NotNull Node node) {
        return loadPane(instance, node, JavaPlugin.getProvidingPlugin(Gui.class));
    }

    /**
     * Processes the annotations that appear on method bodies. The annotations that are specified and the action that
     * corresponds to these annotations are specified in the map. The type parameter specifies which parameter type may
     * appear in the method for these annotations.
     *
     * @param map the map of annotations and their associated action
     * @param type the class of parameter that is accepted as a parameter
     * @param <T> the type of parameter that is accepted as a parameter
     * @since 0.1.0
     */
    private <T> void processMethodAnnotations(@NotNull Map<? extends Class<? extends Annotation>, BiConsumer<? super Gui, Consumer<? super T>>> map,
                                              @NotNull Class<T> type) {
        Set<Class<?>> processed = new HashSet<>();

        for (Method method : getClass().getDeclaredMethods()) {
            int parameterCount = method.getParameterCount();
            Class<?> parameter = parameterCount != 0 ? method.getParameterTypes()[0] : null;

            for (Map.Entry<? extends Class<? extends Annotation>, BiConsumer<? super Gui, Consumer<? super T>>> entry : map.entrySet()) {
                Class<? extends Annotation> annotation = entry.getKey();

                if (method.isAnnotationPresent(annotation)) {
                    if (processed.contains(annotation))
                        throw new MultipleAnnotationsException(annotation.getSimpleName() + " appears multiple times");

                    processed.add(annotation);

                    if (parameterCount != 0 && (parameterCount != 1 || !parameter.isAssignableFrom(type)))
                        throw new InvalidParametersException("Invalid parameters for " + annotation.getSimpleName());

                    entry.getValue().accept(this, event -> {
                        try {
                            if (parameterCount == 0) {
                                method.invoke(this);
                            } else {
                                method.invoke(this, event);
                            }
                        } catch (IllegalAccessException | InvocationTargetException exception) {
                            throw new RuntimeException(exception);
                        }
                    });
                }
            }
        }
    }

    /**
     * Processes all the annotations that might be present in a subclass of this class.
     *
     * @since 0.1.0
     */
    private void processAnnotations() {
        processMethodAnnotations(CLICK_ANNOTATIONS, InventoryClickEvent.class);
        processMethodAnnotations(DRAG_ANNOTATIONS, InventoryDragEvent.class);
        processMethodAnnotations(CLOSE_ANNOTATIONS, InventoryCloseEvent.class);
    }

    /**
     * Registers the legacy smithing table. It is deprecated, but still loadable from XML for 1.16 - 1.19.4.
     */
    @SuppressWarnings("deprecation")
    private static void registerLegacySmithingTable() {
        registerGui("smithing-table",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) SmithingTableGui::load);
    }

    static {
        registerPane("masonrypane",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) MasonryPane::load);
        registerPane("outlinepane",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) OutlinePane::load);
        registerPane("paginatedpane",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) PaginatedPane::load);
        registerPane("patternpane",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) PatternPane::load);
        registerPane("staticpane",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) StaticPane::load);

        registerPane("cyclebutton",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) CycleButton::load);
        registerPane("label",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) Label::load);
        registerPane("pagingbuttons", PagingButtons::load);
        registerPane("percentagebar",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) PercentageBar::load);
        registerPane("slider",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) Slider::load);
        registerPane("togglebutton",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Pane>) ToggleButton::load);

        registerGui("anvil",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) AnvilGui::load);
        registerGui("barrel",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) BarrelGui::load);
        registerGui("beacon",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) BeaconGui::load);
        registerGui("blast-furnace",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) BlastFurnaceGui::load);
        registerGui("brewing-stand",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) BrewingStandGui::load);
        registerGui("cartography-table",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) CartographyTableGui::load);
        registerGui("chest",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) ChestGui::load);
        registerGui("crafting-table",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) CraftingTableGui::load);
        registerGui("dispenser",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) DispenserGui::load);
        registerGui("dropper",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) DropperGui::load);
        registerGui("enchanting-table",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) EnchantingTableGui::load);
        registerGui("ender-chest",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) EnderChestGui::load);
        registerGui("furnace",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) FurnaceGui::load);
        registerGui("grindstone",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) GrindstoneGui::load);
        registerGui("hopper",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) HopperGui::load);
        registerGui("loom",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) LoomGui::load);
        registerGui("merchant",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) MerchantGui::load);
        registerGui("shulker-box",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) ShulkerBoxGui::load);
        registerLegacySmithingTable();
        registerGui("smoker",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) SmokerGui::load);
        registerGui("stonecutter",
                (TriFunction<? super Object, ? super Element, ? super Plugin, ? extends Gui>) StonecutterGui::load);

        CLICK_ANNOTATIONS.put(BottomClickHandler.class, Gui::setOnBottomClick);
        CLICK_ANNOTATIONS.put(GlobalClickHandler.class, Gui::setOnGlobalClick);
        CLICK_ANNOTATIONS.put(OutsideClickHandler.class, Gui::setOnOutsideClick);
        CLICK_ANNOTATIONS.put(TopClickHandler.class, Gui::setOnTopClick);

        DRAG_ANNOTATIONS.put(BottomDragHandler.class, Gui::setOnBottomDrag);
        DRAG_ANNOTATIONS.put(GlobalDragHandler.class, Gui::setOnGlobalDrag);
        DRAG_ANNOTATIONS.put(TopDragHandler.class, Gui::setOnTopDrag);

        CLOSE_ANNOTATIONS.put(CloseHandler.class, Gui::setOnClose);
    }
}
