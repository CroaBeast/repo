package me.croabeast.inventory.gui.type;

import lombok.Getter;
import lombok.Setter;
import me.croabeast.inventory.HumanEntityCache;
import me.croabeast.inventory.nms.MerchantInventory;
import me.croabeast.inventory.adventure.StringHolder;
import me.croabeast.inventory.adventure.TextHolder;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.type.util.InventoryBased;
import me.croabeast.inventory.gui.type.util.NamedGui;
import me.croabeast.inventory.pane.Pane;
import me.croabeast.inventory.util.XMLUtil;
import me.croabeast.inventory.util.version.Version;
import me.croabeast.inventory.util.version.VersionMatcher;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.TradeSelectEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Represents a gui in the form of a merchant.
 *
 * @since 0.1.0
 */
public class MerchantGui extends NamedGui implements InventoryBased {

    /**
     * The consumer that will be called once a players selects a trade listed
     * on the left side of the gui
     */
    @Setter
    private Consumer<? super TradeSelectEvent> onTradeSelect;

    /**
     * Represents the gui component for the input
     */
    @NotNull
    @Getter
    private GuiComponent inputComponent = new GuiComponent(2, 1);

    /**
     * Represents the gui component for the player inventory
     */
    @NotNull
    @Getter
    private GuiComponent playerGuiComponent = new GuiComponent(9, 4);

    /**
     * The trades of this merchant with their price differences. The differences are the difference between the new
     * price and the original price.
     */
    @NotNull
    private final List<Map.Entry<? extends MerchantRecipe, ? extends Integer>> trades = new ArrayList<>();

    /**
     * The experience of this merchant. Values below zero indicate that the experience should be hidden.
     */
    private int experience = -1;

    /**
     * The level of this merchant. A value of zero indicates this villager doesn't have a level.
     */
    private int level = 0;

    /**
     * The internal merchant inventory
     */
    @NotNull
    private final MerchantInventory merchantInventory = VersionMatcher.newMerchantInventory(Version.getVersion());

    /**
     * Creates a merchant gui with the given title.
     *
     * @param title the title
     * @since 0.1.0
     */
    public MerchantGui(@NotNull String title) {
        this(StringHolder.of(title));
    }

    /**
     * Creates a merchant gui with the given title.
     *
     * @param title the title
     * @since 0.1.0
     */
    public MerchantGui(@NotNull TextHolder title) {
        this(title, JavaPlugin.getProvidingPlugin(MerchantGui.class));
    }

    /**
     * Constructs a new merchant gui for the given {@code plugin}.
     *
     * @param title the title/name of this gui.
     * @param plugin the owning plugin of this gui
     * @see #MerchantGui(String)
     * @since 0.1.0
     */
    public MerchantGui(@NotNull String title, @NotNull Plugin plugin) {
        this(StringHolder.of(title), plugin);
    }

    /**
     * Constructs a new merchant gui for the given {@code plugin}.
     *
     * @param title the title/name of this gui.
     * @param plugin the owning plugin of this gui
     * @see #MerchantGui(TextHolder)
     * @since 0.1.0
     */
    public MerchantGui(@NotNull TextHolder title, @NotNull Plugin plugin) {
        super(title, plugin);
    }

    /**
     * Calls the consumer (if it's not null) that was specified using {@link #setOnTradeSelect(Consumer)},
     * so the consumer that should be called whenever a trade is selected in this gui.
     * Catches and logs all exceptions the consumer might throw.
     *
     * @param event the event to handle
     */
    public void callOnTradeSelect(@NotNull TradeSelectEvent event) {
        callCallback(onTradeSelect, event, "onTradeSelect");
    }

    @Override
    protected void initializeOrThrow(@NotNull Object instance, @NotNull Element element) {
        super.initializeOrThrow(instance, element);

        if (element.hasAttribute("onTradeSelect")) {
            setOnTradeSelect(XMLUtil.loadOnEventAttribute(instance,
                    element, TradeSelectEvent.class, "onTradeSelect"));
        }
    }

    @Override
    public void update() {
        super.updating = true;

        if (isDirty()) {
            Inventory oldInventory = this.inventory;
            this.inventory = createInventory();

            if (oldInventory != null) {
                for (HumanEntity viewer : new ArrayList<>(oldInventory.getViewers())) {
                    viewer.openInventory(this.inventory);
                }
            }

            markChanges();
        }

        getInventory().clear();

        getInputComponent().display(getInventory(), 0);
        getPlayerGuiComponent().display();

        for (HumanEntity viewer : getViewers()) {
            ItemStack cursor = viewer.getItemOnCursor();
            viewer.setItemOnCursor(new ItemStack(Material.AIR));

            populateBottomInventory(viewer);

            if ((this.experience >= 0 || this.level > 0 || !this.trades.isEmpty()) && viewer instanceof Player)
                this.merchantInventory.sendMerchantOffers((Player) viewer, this.trades, this.level, this.experience);

            viewer.setItemOnCursor(cursor);
        }

        if (!super.updating)
            throw new AssertionError("Gui#isUpdating became false before Gui#update finished");

        super.updating = false;
    }

    @NotNull
    public Iterable<? extends GuiItem> getItems() {
        Collection<@NotNull GuiItem> items = new HashSet<>();

        for (Pane pane : getInputComponent().getPanes()) {
            items.addAll(pane.getItems());
        }

        for (Pane pane : getPlayerGuiComponent().getPanes()) {
            items.addAll(pane.getItems());
        }

        return items;
    }

    @Override
    public void show(@NotNull HumanEntity humanEntity) {
        if (!(humanEntity instanceof Player))
            throw new IllegalArgumentException("Merchants can only be opened by players");

        if (isDirty())
            update();

        populateBottomInventory(humanEntity);

        humanEntity.openInventory(getInventory());

        if (this.experience >= 0 || this.level > 0 || !this.trades.isEmpty())
            this.merchantInventory.sendMerchantOffers((Player) humanEntity, this.trades, this.level, this.experience);
    }

    /**
     * Populates the inventory of the {@link HumanEntity} if needed.
     *
     * @param humanEntity the human entity
     * @since 0.1.0
     */
    private void populateBottomInventory(@NotNull HumanEntity humanEntity) {
        if (getPlayerGuiComponent().hasItem()) {
            HumanEntityCache humanEntityCache = getHumanEntityCache();

            if (!humanEntityCache.contains(humanEntity))
                humanEntityCache.storeAndClear(humanEntity);

            getPlayerGuiComponent().placeItems(humanEntity.getInventory(), 0);
        }
    }

    @NotNull
    public Gui copy() {
        MerchantGui gui = new MerchantGui(getTitleHolder(), super.plugin);

        gui.inputComponent = inputComponent.copy();
        gui.playerGuiComponent = this.playerGuiComponent.copy();

        gui.experience = experience;
        gui.level = level;

        for (Map.Entry<? extends MerchantRecipe, ? extends Integer> trade : trades) {
            MerchantRecipe originalRecipe = trade.getKey();

            ItemStack result = originalRecipe.getResult().clone();
            int uses = originalRecipe.getUses();
            int maxUses = originalRecipe.getMaxUses();
            boolean experienceReward = originalRecipe.hasExperienceReward();
            int villagerExperience = originalRecipe.getVillagerExperience();
            float priceMultiplier = originalRecipe.getPriceMultiplier();

            MerchantRecipe recipe = new MerchantRecipe(
                    result, uses, maxUses, experienceReward, villagerExperience, priceMultiplier
            );

            for (ItemStack ingredient : originalRecipe.getIngredients()) {
                recipe.addIngredient(ingredient.clone());
            }

            gui.trades.add(new AbstractMap.SimpleImmutableEntry<>(recipe, trade.getValue()));
        }

        gui.setOnTopClick(this.onTopClick);
        gui.setOnBottomClick(this.onBottomClick);
        gui.setOnGlobalClick(this.onGlobalClick);
        gui.setOnOutsideClick(this.onOutsideClick);
        gui.setOnTradeSelect(this.onTradeSelect);
        gui.setOnClose(this.onClose);

        return gui;
    }

    @Override
    public void click(@NotNull InventoryClickEvent event) {
        int rawSlot = event.getRawSlot();

        if (rawSlot >= 0 && rawSlot <= 1) {
            getInputComponent().click(this, event, rawSlot);
        } else if (rawSlot != 2) {
            getPlayerGuiComponent().click(this, event, rawSlot - 3);
        }
    }

    @NotNull
    public Inventory getInventory() {
        if (this.inventory == null)
            this.inventory = createInventory();

        return inventory;
    }

    @NotNull
    public Inventory createInventory() {
        Inventory inventory = this.merchantInventory.createInventory(getTitleHolder());

        addInventory(inventory, this);

        return inventory;
    }

    /**
     * Adds a trade to this gui. The specified discount is the difference between the old price and the new price. For
     * example, if a price was decreased from five to two, the discount would be three.
     *
     * @param recipe the recipe to add
     * @param discount the discount
     * @since 0.1.0
     */
    public void addTrade(@NotNull MerchantRecipe recipe, int discount) {
        this.trades.add(new AbstractMap.SimpleImmutableEntry<>(recipe, -discount));
    }

    /**
     * Sets the experience of this merchant gui. Setting the experience will make the experience bar visible, even if
     * the amount of experience is zero. Note that if the level of this merchant gui has not been set via
     * {@link #setLevel(int)} that the experience will always show as zero even when set to something else. Experience
     * must be greater than or equal to zero. Attempting to set the experience to below zero will throw an
     * {@link IllegalArgumentException}.
     *
     * @param experience the experience to set
     * @since 0.1.0
     * @throws IllegalArgumentException when the experience is below zero
     */
    public void setExperience(int experience) {
        if (experience < 0)
            throw new IllegalArgumentException("Experience must be greater than or equal to zero");

        this.experience = experience;
    }

    /**
     * Sets the level of this merchant gui. This is a value between one and five and will visibly change the gui by
     * appending the level of the villager to the title. These are displayed as "Novice", "Apprentice", "Journeyman",
     * "Expert" and "Master" respectively (when the player's locale is set to English). When an argument is supplied
     * that is not within one and five, an {@link IllegalArgumentException} will be thrown.
     *
     * @param level the numeric level
     * @since 0.1.0
     * @throws IllegalArgumentException when the level is not between one and five
     */
    public void setLevel(int level) {
        if (level < 0 || level > 5)
            throw new IllegalArgumentException("Level must be between one and five");

        this.level = level;
    }

    /**
     * Adds a trade to this gui. This will not set a discount on the trade. For specifiying discounts, see
     * {@link #addTrade(MerchantRecipe, int)}.
     *
     * @param recipe the recipe to add
     * @since 0.1.0
     */
    public void addTrade(@NotNull MerchantRecipe recipe) {
        addTrade(recipe, 0);
    }

    @Override
    public boolean isPlayerInventoryUsed() {
        return getPlayerGuiComponent().hasItem();
    }

    @Override
    public int getViewerCount() {
        return getInventory().getViewers().size();
    }

    @NotNull
    public List<HumanEntity> getViewers() {
        return new ArrayList<>(getInventory().getViewers());
    }

    /**
     * Loads a merchant gui from an XML file.
     *
     * @param instance the instance on which to reference fields and methods
     * @param inputStream the input stream containing the XML data
     * @param plugin the plugin that will be the owner of the created gui
     * @return the loaded merchant gui
     * @see #load(Object, InputStream)
     * @since 0.1.0
     */
    @Nullable
    public static MerchantGui load(@NotNull Object instance, @NotNull InputStream inputStream, @NotNull Plugin plugin) {
        try {
            Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputStream);
            Element documentElement = document.getDocumentElement();

            documentElement.normalize();

            return load(instance, documentElement, plugin);
        } catch (SAXException | ParserConfigurationException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Loads a merchant gui from the specified element, applying code references to the provided instance.
     *
     * @param instance the instance on which to reference fields and methods
     * @param element the element to load the gui from
     * @param plugin the plugin that will be the owner of the created gui
     * @return the loaded merchant gui
     * @see #load(Object, Element)
     * @since 0.1.0
     */
    @NotNull
    public static MerchantGui load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("title"))
            throw new XMLLoadException("Provided XML element's gui tag doesn't have the mandatory title attribute set");

        MerchantGui merchantGui = new MerchantGui(element.getAttribute("title"), plugin);
        merchantGui.initializeOrThrow(instance, element);

        if (element.hasAttribute("populate"))
            return merchantGui;

        NodeList childNodes = element.getChildNodes();

        for (int index = 0; index < childNodes.getLength(); index++) {
            Node item = childNodes.item(index);

            if (item.getNodeType() != Node.ELEMENT_NODE)
                continue;

            Element nestedElement = (Element) item;
            String tagName = nestedElement.getTagName();

            if (tagName.equalsIgnoreCase("component")) {
                if (!nestedElement.hasAttribute("name"))
                    throw new XMLLoadException("Component tag does not have a name specified");

                GuiComponent component;

                switch (nestedElement.getAttribute("name")) {
                    case "input":
                        component = merchantGui.getInputComponent();
                        break;
                    case "player-inventory":
                        component = merchantGui.getPlayerGuiComponent();
                        break;
                    default:
                        throw new XMLLoadException("Unknown component name");
                }

                component.load(instance, nestedElement, plugin);
            } else if (tagName.equalsIgnoreCase("trade")) {
                NodeList tradeNodes = nestedElement.getChildNodes();

                List<ItemStack> ingredients = new ArrayList<>(2);
                ItemStack result = null;

                for (int tradeIndex = 0; tradeIndex < tradeNodes.getLength(); tradeIndex++) {
                    Node tradeNode = tradeNodes.item(tradeIndex);

                    if (tradeNode.getNodeType() != Node.ELEMENT_NODE)
                        continue;

                    Element tradeElement = (Element) tradeNode;

                    if (tradeElement.getTagName().equalsIgnoreCase("ingredient")) {
                        if (ingredients.size() >= 2)
                            throw new XMLLoadException("Too many ingredients specified, must be no more than two");

                        NodeList ingredientNodes = tradeElement.getChildNodes();

                        for (int ingredientIndex = 0; ingredientIndex < ingredientNodes.getLength(); ingredientIndex++) {
                            Node ingredientNode = ingredientNodes.item(ingredientIndex);

                            if (ingredientNode.getNodeType() != Node.ELEMENT_NODE)
                                continue;

                            ingredients.add(GuiItem.loadItem(instance, (Element) ingredientNode).getItem());
                        }
                    } else if (tradeElement.getTagName().equalsIgnoreCase("result")) {
                        NodeList resultNodes = tradeElement.getChildNodes();

                        for (int resultIndex = 0; resultIndex < resultNodes.getLength(); resultIndex++) {
                            Node resultNode = resultNodes.item(resultIndex);

                            if (resultNode.getNodeType() != Node.ELEMENT_NODE)
                                continue;

                            if (result != null)
                                throw new XMLLoadException("Multiple results specified for the same trade");

                            result = GuiItem.loadItem(instance, (Element) resultNode).getItem();
                        }
                    } else {
                        throw new XMLLoadException("Trade element is neither an ingredient nor a result");
                    }
                }

                if (result == null)
                    throw new XMLLoadException("Trade must have a result specified");

                if (ingredients.size() < 1)
                    throw new XMLLoadException("Trade must have at least one ingredient");

                MerchantRecipe recipe = new MerchantRecipe(result, Integer.MAX_VALUE);

                recipe.setIngredients(ingredients);

                merchantGui.addTrade(recipe);
            } else {
                throw new XMLLoadException("Nested element is neither a component nor a trade");
            }
        }

        return merchantGui;
    }

    /**
     * Loads a merchant gui from an XML file.
     *
     * @param instance the instance on which to reference fields and methods
     * @param inputStream the input stream containing the XML data
     * @return the loaded merchant gui
     * @since 0.1.0
     */
    @Nullable
    public static MerchantGui load(@NotNull Object instance, @NotNull InputStream inputStream) {
        return load(instance, inputStream, JavaPlugin.getProvidingPlugin(MerchantGui.class));
    }

    /**
     * Loads a merchant gui from the specified element, applying code references to the provided instance.
     *
     * @param instance the instance on which to reference fields and methods
     * @param element the element to load the gui from
     * @return the loaded merchant gui
     * @since 0.1.0
     */
    @NotNull
    public static MerchantGui load(@NotNull Object instance, @NotNull Element element) {
        return load(instance, element, JavaPlugin.getProvidingPlugin(MerchantGui.class));
    }
}
