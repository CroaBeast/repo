package me.croabeast.inventory.pane.component;

import lombok.Getter;
import me.croabeast.inventory.gui.GuiComponent;
import me.croabeast.inventory.gui.type.util.Gui;
import me.croabeast.inventory.gui.GuiItem;
import me.croabeast.inventory.exception.XMLLoadException;
import me.croabeast.inventory.pane.OutlinePane;
import me.croabeast.inventory.pane.Pane;
import me.croabeast.inventory.pane.util.GuiItemContainer;
import me.croabeast.inventory.pane.util.Slot;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Element;

import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * A button that toggles between an enabled and disabled state.
 *
 * @since 0.1.0
 */
public class ToggleButton extends Pane {

    /**
     * The panes used for showing the enabled and disabled states
     */
    private final OutlinePane enabledPane, disabledPane;

    /**
     * Whether the button is enabled or disabled
     */
    @Getter
    private boolean enabled;

    /**
     * Whether this button can be toggled by a player
     */
    private boolean allowToggle = true;

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param priority the priority
     * @param enabled whether the button should start in its enabled or disabled state
     * @param plugin the plugin that will be the owner of this button's items
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, @NotNull Priority priority, boolean enabled, @NotNull Plugin plugin) {
        super(length, height, priority);

        this.enabled = enabled;

        this.enabledPane = new OutlinePane(length, height);
        this.enabledPane.addItem(new GuiItem(new ItemStack(Material.GREEN_STAINED_GLASS_PANE), plugin));
        this.enabledPane.setRepeat(true);

        this.disabledPane = new OutlinePane(length, height);
        this.disabledPane.addItem(new GuiItem(new ItemStack(Material.RED_STAINED_GLASS_PANE), plugin));
        this.disabledPane.setRepeat(true);
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param priority the priority
     * @param plugin the plugin that will be the owner of this button's items
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, @NotNull Priority priority, @NotNull Plugin plugin) {
        this(length, height, priority, false, plugin);
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param enabled whether the button should start in its enabled or disabled state
     * @param plugin the plugin that will be the owner of this button's items
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, boolean enabled, @NotNull Plugin plugin) {
        this(length, height, Priority.NORMAL, enabled, plugin);
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param plugin the plugin that will be the owner of this button's items
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, @NotNull Plugin plugin) {
        this(length, height, false, plugin);
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param priority the priority
     * @param enabled whether the button should start in its enabled or disabled state
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, @NotNull Priority priority, boolean enabled) {
        this(length, height, priority, enabled, JavaPlugin.getProvidingPlugin(ToggleButton.class));
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param priority the priority
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, @NotNull Priority priority) {
        this(length, height, priority, false);
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @param enabled whether the button should start in its enabled or disabled state
     * @since 0.1.0
     */
    public ToggleButton(int length, int height, boolean enabled) {
        this(length, height, Priority.NORMAL, enabled);
    }

    /**
     * Creates a new toggle button
     *
     * @param length the length
     * @param height the height
     * @since 0.1.0
     */
    public ToggleButton(int length, int height) {
        this(length, height, false);
    }

    @NotNull
    public GuiItemContainer display() {
        if (enabled) {
            return this.enabledPane.display();
        } else {
            return this.disabledPane.display();
        }
    }

    @Override
    public boolean click(@NotNull Gui gui, @NotNull GuiComponent guiComponent, @NotNull InventoryClickEvent event,
                         @NotNull Slot slot) {
        int x = slot.getX(getLength());
        int y = slot.getY(getLength());

        //this isn't our item
        if (x < 0 || x >= getLength() || y < 0 || y >= getHeight())
            return false;

        if (this.allowToggle)
            toggle();

        callOnClick(event);

        /*
        Since we've toggled before, the click for the panes should be swapped around. If we haven't toggled due to
        allowToggle being false, then we should click the pane corresponding to the current state. An XOR achieves this.
         */
        if (enabled == this.allowToggle) {
            this.disabledPane.click(gui, guiComponent, event, slot);
        } else {
            this.enabledPane.click(gui, guiComponent, event, slot);
        }

        event.setCancelled(true);

        gui.update();

        return true;
    }

    @NotNull
    public ToggleButton copy() {
        ToggleButton toggleButton = new ToggleButton(getLength(), getHeight(), getPriority(), isEnabled());

        toggleButton.allowToggle = this.allowToggle;

        toggleButton.setVisible(isVisible());
        toggleButton.onClick = onClick;

        toggleButton.uuid = uuid;

        toggleButton.setEnabledItem(enabledPane.getItems().get(0).copy());
        toggleButton.setDisabledItem(disabledPane.getItems().get(0).copy());

        return toggleButton;
    }

    @Override
    public void setLength(int length) {
        super.setLength(length);

        this.disabledPane.setLength(length);
        this.enabledPane.setLength(length);
    }

    @Override
    public void setHeight(int height) {
        super.setHeight(height);

        this.disabledPane.setHeight(height);
        this.enabledPane.setHeight(height);
    }

    /**
     * Sets the item to use when the button is set to disabled
     *
     * @param item the disabled item
     * @since 0.1.0
     */
    public void setDisabledItem(@NotNull GuiItem item) {
        disabledPane.clear();

        disabledPane.addItem(item);
    }

    /**
     * Sets the item to use when the button is set to enabled
     *
     * @param item the enabled item
     * @since 0.1.0
     */
    public void setEnabledItem(@NotNull GuiItem item) {
        enabledPane.clear();

        enabledPane.addItem(item);
    }

    @NotNull
    public Collection<GuiItem> getItems() {
        return getPanes().stream().flatMap(pane -> pane.getItems().stream()).collect(Collectors.toSet());
    }

    @NotNull
    public Collection<Pane> getPanes() {
        return Stream.of(enabledPane, disabledPane).collect(Collectors.toSet());
    }

    /**
     * Sets whether this toggle button can be toggled. This only prevents players from toggling the button and does not
     * prevent toggling the button programmatically with methods such as {@link #toggle()}.
     *
     * @param allowToggle whether this button can be toggled
     * @since 0.1.0
     */
    public void allowToggle(boolean allowToggle) {
        this.allowToggle = allowToggle;
    }

    /**
     * Toggles between the enabled and disabled states
     *
     * @since 0.1.0
     */
    public void toggle() {
        enabled = !enabled;
    }

    @Override
    public void clear() {}

    /**
     * Loads a toggle button from an XML element
     *
     * @param instance the instance class
     * @param element the element
     * @param plugin the plugin that will be the owner of the underlying items
     * @return the toggle button
     * @since 0.1.0
     */
    @NotNull
    public static ToggleButton load(@NotNull Object instance, @NotNull Element element, @NotNull Plugin plugin) {
        if (!element.hasAttribute("length"))
            throw new XMLLoadException("Toggle button XML tag does not have the mandatory length attribute");

        if (!element.hasAttribute("height"))
            throw new XMLLoadException("Toggle button XML tag does not have the mandatory height attribute");

        int length;
        int height;

        try {
            length = Integer.parseInt(element.getAttribute("length"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Length attribute is not an integer", exception);
        }

        try {
            height = Integer.parseInt(element.getAttribute("height"));
        } catch (NumberFormatException exception) {
            throw new XMLLoadException("Height attribute is not an integer", exception);
        }

        boolean enabled = element.hasAttribute("enabled") && Boolean.parseBoolean(element.getAttribute("enabled"));
        ToggleButton toggleButton = new ToggleButton(length, height, enabled, plugin);

        Pane.load(toggleButton, instance, element);

        return toggleButton;
    }
}
