package me.croabeast.common.time;

import com.google.common.base.Preconditions;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.SneakyThrows;
import me.croabeast.common.util.Exceptions;
import org.apache.commons.lang.StringUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * Represents a collection of string formats for different time units.
 * <p>
 * {@code TimeValues} holds configurable formatting strings for seconds, minutes, hours,
 * days, weeks, months, and years. It is designed to support multiple languages and custom formatting.
 * The class includes pre-defined instances such as {@link #DEFAULT_KEYS} and {@link #SPANISH_KEYS}.
 * Once an instance is "locked" (i.e. modification is disabled), its values cannot be changed.
 * </p>
 * <p>
 * The formatting strings are used in conjunction with {@link TimeFormatter} to produce human-readable
 * representations of time durations.
 * </p>
 *
 * <p>
 * Example usage:
 * <pre><code>
 * // Using default keys:
 * TimeValues defaults = TimeValues.DEFAULT_KEYS;
 *
 * // Customizing for Spanish:
 * TimeValues spanish = TimeValues.SPANISH_KEYS;
 *
 * // Load from configuration:
 * ConfigurationSection section = ...;
 * TimeValues configValues = TimeValues.fromSection(section);
 * </code></pre>
 * </p>
 */
@Getter
public class TimeValues {

    /**
     * Default time unit keys in English.
     */
    public static final TimeValues DEFAULT_KEYS = new TimeValues(false);

    /**
     * Predefined time unit keys for Spanish language.
     */
    public static final TimeValues SPANISH_KEYS = new TimeValues()
            .setSecondsFormat("Segundo(s)")
            .setMinutesFormat("Minuto(s)")
            .setHoursFormat("Hora(s)")
            .setDaysFormat("Día(s)")
            .setWeeksFormat("Semana(s)")
            .setMonthsFormat("Mes(es)")
            .setYearsFormat("Año(s)").toggleModification();

    /** Whether this instance can still be modified; {@code false} means it is locked. */
    @Getter(AccessLevel.NONE)
    private boolean modify = true;

    /**
     * The delimiter used to separate time unit segments in the final formatted output.
     */
    @NotNull
    private String splitter = ", ";

    /** The format string representing seconds (e.g., {@code "Second(s)"}). */
    private String secondsFormat = "Second(s)";
    /** The format string representing minutes (e.g., {@code "Minute(s)"}). */
    private String minutesFormat = "Minute(s)";
    /** The format string representing hours (e.g., {@code "Hour(s)"}). */
    private String hoursFormat = "Hour(s)";
    /** The format string representing days (e.g., {@code "Day(s)"}). */
    private String daysFormat = "Day(s)";
    /** The format string representing weeks (e.g., {@code "Week(s)"}). */
    private String weeksFormat = "Week(s)";
    /** The format string representing months (e.g., {@code "Month(s)"}). */
    private String monthsFormat = "Month(s)";
    /** The format string representing years (e.g., {@code "Year(s)"}). */
    private String yearsFormat = "Year(s)";

    /**
     * Creates a new instance with the modification flag set to {@code b}.
     *
     * @param b {@code true} to allow modifications; {@code false} to lock the instance immediately
     */
    private TimeValues(boolean b) {
        this.modify = b;
    }

    /** Creates a new modifiable instance with all default format strings. */
    private TimeValues() {}

    /**
     * Creates a new instance by copying all values from the given {@code TimeValues}.
     *
     * @param values the source instance to copy from
     */
    private TimeValues(TimeValues values) {
        modify = values.modify;
        splitter = values.getSplitter();

        secondsFormat = values.getSecondsFormat();
        minutesFormat = values.getMinutesFormat();
        hoursFormat = values.getHoursFormat();
        daysFormat = values.getDaysFormat();
        weeksFormat = values.getWeeksFormat();
        monthsFormat = values.getMonthsFormat();
        yearsFormat = values.getYearsFormat();
    }

    /**
     * Toggles the modification flag, allowing or disallowing further modifications to this instance.
     *
     * @return this instance after toggling modification
     */
    private TimeValues toggleModification() {
        this.modify = !this.modify;
        return this;
    }

    /**
     * Ensures that this instance is modifiable.
     *
     * @throws IllegalArgumentException if the instance is locked from modifications
     */
    @SneakyThrows
    private void checkModification() {
        Preconditions.checkArgument(modify, "Instance can't be modified");
    }

    /**
     * Sets the splitter string used between time unit segments.
     *
     * @param splitter the new splitter string (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setSplitter(String splitter) {
        checkModification();
        this.splitter = Exceptions.validate(splitter, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for seconds.
     *
     * @param secondsFormat the format string for seconds (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setSecondsFormat(String secondsFormat) {
        checkModification();
        this.secondsFormat = Exceptions.validate(secondsFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for minutes.
     *
     * @param minutesFormat the format string for minutes (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setMinutesFormat(String minutesFormat) {
        checkModification();
        this.minutesFormat = Exceptions.validate(minutesFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for hours.
     *
     * @param hoursFormat the format string for hours (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setHoursFormat(String hoursFormat) {
        checkModification();
        this.hoursFormat = Exceptions.validate(hoursFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for days.
     *
     * @param daysFormat the format string for days (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setDaysFormat(String daysFormat) {
        checkModification();
        this.daysFormat = Exceptions.validate(daysFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for weeks.
     *
     * @param weeksFormat the format string for weeks (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setWeeksFormat(String weeksFormat) {
        checkModification();
        this.weeksFormat = Exceptions.validate(weeksFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for months.
     *
     * @param monthsFormat the format string for months (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setMonthsFormat(String monthsFormat) {
        checkModification();
        this.monthsFormat = Exceptions.validate(monthsFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Sets the format string for years.
     *
     * @param yearsFormat the format string for years (must not be blank)
     * @return this {@code TimeValues} instance for chaining
     */
    public TimeValues setYearsFormat(String yearsFormat) {
        checkModification();
        this.yearsFormat = Exceptions.validate(yearsFormat, StringUtils::isNotBlank);
        return this;
    }

    /**
     * Creates a new modifiable instance of {@code TimeValues}.
     *
     * @return a new {@code TimeValues} instance with default formats
     */
    public static TimeValues create() {
        return new TimeValues();
    }

    /**
     * Creates a {@code TimeValues} instance from a configuration section.
     * <p>
     * The configuration should contain keys such as "splitter", "seconds", "minutes", "hours",
     * "days", "weeks", "months", and "years". If a key is missing or invalid, the corresponding
     * default value is retained.
     * </p>
     *
     * @param section the configuration section containing time format settings
     * @return a new {@code TimeValues} instance loaded from the configuration
     * @throws NullPointerException if the configuration section is {@code null}
     */
    public static TimeValues fromSection(ConfigurationSection section) {
        Objects.requireNonNull(section);

        TimeValues values = new TimeValues(DEFAULT_KEYS);
        values.toggleModification();

        applyIfPresent(section, "splitter", values::setSplitter);
        applyIfPresent(section, "seconds", values::setSecondsFormat);
        applyIfPresent(section, "minutes", values::setMinutesFormat);
        applyIfPresent(section, "hours", values::setHoursFormat);
        applyIfPresent(section, "days", values::setDaysFormat);
        applyIfPresent(section, "weeks", values::setWeeksFormat);
        applyIfPresent(section, "months", values::setMonthsFormat);
        applyIfPresent(section, "years", values::setYearsFormat);

        return values;
    }

    /**
     * Applies a configured value, leaving the default in place when the key is absent or blank.
     *
     * <p>The setters reject a blank value by throwing, which the loader used to express by
     * wrapping every call in an empty catch.
     */
    private static void applyIfPresent(ConfigurationSection section, String key, Consumer<String> setter) {
        String value = section.getString(key);
        if (StringUtils.isNotBlank(value)) setter.accept(value);
    }
}
