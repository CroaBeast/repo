package me.croabeast.common.gui;

import com.github.stefvanschie.inventoryframework.gui.type.ChestGui;
import com.github.stefvanschie.inventoryframework.pane.PaginatedPane;
import me.croabeast.common.CommonServices;
import me.croabeast.prismatic.PrismaticAPI;
import me.croabeast.vnc.VNC;
import org.bukkit.entity.HumanEntity;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

/**
 * A builder for creating and managing a chest GUI with paginated panes.
 * <p>
 * The {@code ChestBuilder} provides a fluent API to configure a chest GUI by setting the number of rows,
 * the display name, and the currently visible page. It extends {@link GuiBuilder} and uses a {@link PaginatedPane}
 * to manage multiple pages of content. The builder also supports showing the GUI to a human entity.
 * </p>
 *
 * <p>
 * Example usage:
 * <pre><code>
 * ChestBuilder chest = new ChestBuilder(4, "&amp;aMy Chest GUI");
 * chest.setDisplayedPage(2).showGui(player);
 * </code></pre>
 * </p>
 *
 * @see ChestGui
 * @see GuiBuilder
 */
public final class ChestBuilder extends GuiBuilder<ChestGui, ChestBuilder> {

    /**
     * Whether menus can be created on this server. InventoryFramework's {@code Gui} constructor
     * throws on versions it has no NMS for, so no {@link ChestGui} is created before 1.16.
     */
    public static final boolean SUPPORTED = VNC.SERVER_VERSION >= 16;

    private static boolean warned = false;

    private final Plugin plugin;
    private boolean loaded = false;

    ChestBuilder(Plugin plugin, int rows, String name) {
        super(new PaginatedPane(9, rows), SUPPORTED ? new ChestGui(rows, PrismaticAPI.colorize(name), plugin) : null);
        this.plugin = plugin;
    }

    /**
     * Sets the displayed page for the chest GUI.
     * <p>
     * If a valid row count is provided (greater than 0), the pane's height and the GUI's row count
     * are updated accordingly. Then, the specified page is set and the GUI is refreshed.
     * </p>
     *
     * @param rows  the number of rows to display (or -1 to use the default)
     * @param index the index of the page to display
     */
    @Override
    public void setDisplayedPage(int rows, int index) {
        if (!SUPPORTED) return;

        if (rows > 0) {
            pane.setHeight(rows);
            value.setRows(rows);
        }

        pane.setPage(index);
        value.update();
    }

    /**
     * Displays the chest GUI to the specified human entity.
     * <p>
     * The GUI is added only once. On first display, the builder adds the paginated pane to the GUI,
     * and subsequent calls simply show the GUI.
     * </p>
     *
     * @param entity the human entity (typically a player) to show the GUI to
     */
    @Override
    public void showGui(HumanEntity entity) {
        if (!SUPPORTED) {
            if (!warned) {
                plugin.getLogger().warning("Menus are not available on this server version: they require Minecraft 1.16 or newer.");
                warned = true;
            }
            entity.sendMessage("Menus require Minecraft 1.16 or newer.");
            return;
        }
        if (!loaded) {
            value.addPane(com.github.stefvanschie.inventoryframework.pane.util.Slot.fromXY(0, 0), pane);
            loaded = true;
        }
        value.show(entity);
    }

    /**
     * Returns this instance of {@code ChestBuilder} for fluent chaining.
     *
     * @return this builder instance
     */
    @NotNull
    public ChestBuilder instance() {
        return this;
    }

    /**
     * Creates a new {@code ChestBuilder} for the given plugin, row count, and display name.
     *
     * @param plugin the plugin owning this GUI
     * @param rows   the number of rows in the chest (1–6)
     * @param name   the display name shown in the chest GUI title bar
     * @return a new {@code ChestBuilder} instance
     */
    @NotNull
    public static ChestBuilder of(Plugin plugin, int rows, String name) {
        return new ChestBuilder(plugin, rows, Objects.requireNonNull(name));
    }

    /**
     * Creates a new {@code ChestBuilder} using the common plugin from {@link CommonServices}.
     *
     * @param rows the number of rows in the chest (1–6)
     * @param name the display name shown in the chest GUI title bar
     * @return a new {@code ChestBuilder} instance
     */
    @NotNull
    public static ChestBuilder of(int rows, String name) {
        return of(CommonServices.getPlugin(), rows, name);
    }
}
