package me.croabeast.takion.marker;

import me.croabeast.takion.token.Token;

/**
 * A control marker used by the text preparation pipeline.
 *
 * <p>Resolves to the text that replaces the match.
 */
public interface Marker extends Token<String> {}
