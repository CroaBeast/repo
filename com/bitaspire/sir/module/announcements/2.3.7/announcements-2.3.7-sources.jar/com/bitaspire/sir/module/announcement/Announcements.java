package com.bitaspire.sir.module.announcement;

import lombok.Getter;
import me.croabeast.scheduler.GlobalTask;
import com.bitaspire.sir.ChatToggleable;
import com.bitaspire.sir.file.ExtensionFile;
import com.bitaspire.sir.command.CommandProvider;
import com.bitaspire.sir.command.SIRCommand;
import com.bitaspire.sir.module.SIRModule;
import me.croabeast.takion.logger.LogLevel;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Announcements extends SIRModule implements CommandProvider, ChatToggleable {

    @Getter
    private final Set<SIRCommand> commands = new HashSet<>();

    Config config;
    Data data;

    private GlobalTask task;
    private int count = 0;

    private void start() {
        if (!isEnabled() || config.getInterval() <= 0 || task != null)
            return;

        if (data.getAnnouncements().isEmpty()) {
            getLogger().log(LogLevel.WARN, "No announcements configured; announcement task will not start.");
            return;
        }

        task = getApi().getScheduler().runTaskTimer(
                () -> {
                    int size = data.getAnnouncements().size() - 1;
                    if (count > size) count = 0;

                    Announcement unit = data.fromIndex(count);
                    if (unit != null) unit.announce();

                    if (config.isRandom()) {
                        count = new Random().nextInt(size + 1);
                        return;
                    }

                    count = count < size ? (count + 1) : 0;
                },
                0L, config.getInterval()
        );
    }

    private void stop() {
        if (task == null) return;

        task.cancel();
        task = null;
    }

    @Override
    public boolean register() {
        config = new Config(this);
        data = new Data(this);

        try {
            commands.clear();
            commands.add(new Command(this, new ExtensionFile(this, "lang", true)));
        } catch (Exception e) {
            getLogger().log(LogLevel.ERROR, "Command 'announce' cannot be loaded due to lang.yml was missing");
            e.printStackTrace();
        }

        start();
        return true;
    }

    @Override
    public boolean unregister() {
        stop();
        return true;
    }

    public void announce(String id) {
        Announcement announcement = data.getAnnouncements().get(id);
        if (announcement != null) announcement.announce();
    }
}
