package com.bitaspire.sir.command;

import lombok.AccessLevel;
import lombok.Getter;
import me.croabeast.file.Configurable;
import org.apache.commons.lang.StringUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.jetbrains.annotations.ApiStatus;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Getter
public final class CommandFile {

    private final String name, permission;
    private final boolean override;

    private final List<String> aliases;
    private final Map<String, String> subCommands;

    private final String description, usage;
    private final String permissionMessage;

    @Getter(AccessLevel.NONE)
    final boolean hasParent;
    final String parentName;

    @ApiStatus.Internal
    public CommandFile(String name, ConfigurationSection section, SIRCommand parent, boolean override) {
        Objects.requireNonNull(section, "Configuration section cannot be null");

        this.name = Objects.requireNonNull(name, "Command name cannot be null");
        permission = section.getString("permission", "sir." + this.name);
        Objects.requireNonNull(permission, "Command permission cannot be null");

        aliases = Configurable.toStringList(section, "aliases");

        Map<String, String> subCommands = new LinkedHashMap<>();
        ConfigurationSection sub = section.getConfigurationSection("sub-commands");
        if (sub != null)
            sub.getKeys(false).forEach(key -> {
                String temp = sub.getString(key);
                if (StringUtils.isBlank(temp)) temp = permission + "." + key;
                subCommands.put(key, temp);
            });

        this.subCommands = new LinkedHashMap<>(subCommands);

        description = section.getString("description", "");
        usage = section.getString("usage", "/" + this.name);
        permissionMessage = section.getString("permission-message", "You do not have permission to execute this command.");

        this.hasParent = section.getBoolean("depends.enabled");
        parentName = section.getString("depends.parent");

        SIRCommand resolved = hasParent() && parent != null &&
                !parent.getName().equalsIgnoreCase(parentName) ? parent : null;

        boolean resolvedOverride = override;
        if (hasParent() && resolved != null) resolvedOverride = resolved.isOverriding();
        this.override = resolvedOverride;
    }

    public boolean hasParent() {
        return hasParent && StringUtils.isNotBlank(parentName);
    }
}
