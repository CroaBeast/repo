package com.bitaspire.sir.addon;

import com.github.stefvanschie.inventoryframework.pane.util.Slot;
import com.google.common.base.Preconditions;
import lombok.Getter;
import me.croabeast.common.util.ArrayUtils;
import me.croabeast.file.Configurable;
import com.bitaspire.sir.Information;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public final class AddonInformation implements Information {

    @NotNull
    private final String main, name, title;

    private final String[] description;
    private final Slot slot;

    private final List<String> depend, softDepend;

    @ApiStatus.Internal
    public AddonInformation(FileConfiguration configuration) {
        String main = configuration.getString("main");
        Preconditions.checkArgument(StringUtils.isNotBlank(main), "Addon main class cannot be null or empty");
        this.main = main;

        String[] mainParts = main.split("\\.");
        this.name = configuration.getString("name", mainParts[mainParts.length - 1]);

        List<String> list = ArrayUtils.toList(name.replaceAll("[-_]", " ").split(" "));
        list.replaceAll(WordUtils::capitalize);
        this.title = configuration.getString("title", String.join(" ", list));

        this.description = Configurable.toStringList(configuration, "description").toArray(new String[0]);
        this.slot = Slot.fromXY(0, 0);

        this.depend = Collections.unmodifiableList(Configurable.toStringList(configuration, "depend"));

        List<String> soft = Configurable.toStringList(configuration, "soft-depend");
        this.softDepend = Collections.unmodifiableList(soft.stream().distinct().collect(Collectors.toList()));
    }
}
